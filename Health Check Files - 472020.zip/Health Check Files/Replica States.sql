select *
from sys.dm_hadr_availability_replica_states