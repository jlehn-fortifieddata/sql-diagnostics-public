/*============================================================================
  File:     Locking - Page Splits

  Summary:  Display operational stats for indexes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[Server Name] [nvarchar](128) NULL,
	[DB Name] [nvarchar](128) NULL,
	[object_nm] [nvarchar](128) NULL,
	[index_id] [int] NOT NULL,
	[partition_number] [int] NOT NULL,
	[leaf_allocation_count] [bigint] NOT NULL,
	[nonleaf_allocation_count] [bigint] NOT NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (2, 4)
		AND SD.compatibility_level > 80

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

	SET @usecmd = 'USE [' + @DBName + '];'
	SET @sqlcmd = '
	--The following query demonstrates identifying the top 3 objects associated with waits on page locks:
		INSERT INTO tempdb.dbo.Results
		SELECT TOP 30
			@@SERVERNAME AS [Server Name] 
			, db_name() AS [DB Name]
			, OBJECT_NAME(object_id, database_id) object_nm
			, index_id
			, partition_number
			, leaf_allocation_count
			, nonleaf_allocation_count
		FROM sys.dm_db_index_operational_stats
			  (db_id(), NULL, NULL, NULL)
		WHERE leaf_allocation_count > 0
		ORDER BY leaf_allocation_count DESC

		'

	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT *
FROM tempdb.dbo.Results
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;
