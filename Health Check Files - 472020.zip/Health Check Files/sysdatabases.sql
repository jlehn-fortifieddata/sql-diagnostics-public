select * from sys.databases
