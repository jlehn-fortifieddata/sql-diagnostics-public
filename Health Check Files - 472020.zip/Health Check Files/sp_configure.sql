/*============================================================================
  File:     sp_configure.sql

  Summary:  Displays information about the server.
  
  Date:     2008

  Versions: !!!!!!!!!!2005, 2008 is on the bottom.!!!!!!!!!!!!!!
			Requires KT's 2005 and 2008 modified index scripts.
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SET NOCOUNT ON

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (8,9) 
BEGIN
	exec sp_configure 'show advanced options', 1
	reconfigure with override

	exec sp_configure 

	exec sp_configure 'show advanced options', 0
	reconfigure with override
END

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (1) 
BEGIN
	-- Get configuration values for instance
	SELECT @@servername [Server Name]
		,name
		, value
		, value_in_use
		, [description] 
	FROM sys.configurations
	ORDER BY name
END
