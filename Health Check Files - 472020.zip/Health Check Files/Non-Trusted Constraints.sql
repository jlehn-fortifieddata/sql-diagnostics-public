
/*============================================================================
  File:     Non-Trusted Constraints.sql

  Summary:  Lists all the check constraints that were added with the NOCHECK clause.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/* Create a temporary table to hold our data, since we're going to iterate through databases */
IF OBJECT_ID('tempdb..#Results') IS NOT NULL
    DROP TABLE #Results;
 
CREATE TABLE [dbo].#Results(
	[Server Name] [nvarchar](128) NOT NULL,
	[DB Name] [nvarchar](128) NOT NULL,
	[FK Name] [varchar](1024) NOT NULL
) ON [PRIMARY]

EXECUTE sys.sp_MSforeachdb
	'USE [?]; 

	declare @dbid int

	select @dbid = db_id()

	INSERT INTO #Results
	SELECT @@SERVERNAME AS [Server Name] 
		, DB_NAME() AS [Database Name]
		, i.name
	FROM sys.foreign_keys i 
	JOIN sys.objects o ON i.parent_object_id = o.object_id 
	JOIN sys.schemas s ON o.schema_id = s.schema_id 
	WHERE i.is_not_trusted = 1 
	AND i.is_not_for_replication = 0
	-- Foreign Key Check... Will build the statement below to CHECK (validate) the FK for those FK''s that are untrusted.
	UNION
	SELECT @@SERVERNAME AS [Server Name] 
		, DB_NAME() AS [Database Name]
		, i.name 
	FROM sys.check_constraints i 
	JOIN sys.objects o on i.parent_object_id = o.object_id 
	JOIN sys.schemas s on o.schema_id = s.schema_id 
	WHERE i.is_not_trusted = 1 
	AND i.is_not_for_replication = 0'

SELECT *
FROM #Results
WHERE [DB Name] NOT IN ('MASTER', 'msdb', 'MODEL', 'TEMPDB')

DROP TABLE #Results;

/*
SET NOCOUNT ON

EXECUTE sys.sp_MSforeachdb
	'USE [?]; 

	declare @dbid int

	select @dbid = db_id()

	select ''use ['' + db_name() + '']''
	select ''go''

	select ''ALTER TABLE '' + s.name + ''.'' + OBJECT_NAME(o.object_id) + '' WITH CHECK CHECK CONSTRAINT ['' + i.name + '']
	GO''
	FROM sys.foreign_keys i  INNER JOIN sys.objects o ON i.parent_object_id = o.object_id INNER JOIN sys.schemas s ON o.schema_id = s.schema_id WHERE i.is_not_trusted = 1 AND i.is_not_for_replication = 0
	-- Foreign Key Check... Will build the statement below to CHECK (validate) the FK for those FK''s that are untrusted.
	UNION
	select ''ALTER TABLE '' +  s.name + ''.'' + OBJECT_NAME(o.object_id) + '' WITH CHECK CHECK CONSTRAINT ['' + i.name + '']
	GO''
	from sys.check_constraints i join sys.objects o on i.parent_object_id = o.object_id join sys.schemas s on o.schema_id = s.schema_id where i.is_not_trusted = 1 and i.is_not_for_replication = 0
	-- Check Constraint Check... Will build the statement below to CHECK (validate) the check constraints for those check constraints that are untrusted.'


*/

/*

SELECT DB_NAME() AS 'Database Name'
	, i.name
FROM sys.foreign_keys i 
JOIN sys.objects o ON i.parent_object_id = o.object_id 
JOIN sys.schemas s ON o.schema_id = s.schema_id 
WHERE i.is_not_trusted = 1 
AND i.is_not_for_replication = 0
-- Foreign Key Check... Will build the statement below to CHECK (validate) the FK for those FK's that are untrusted.
UNION
SELECT DB_NAME() AS 'Database Name'
	, i.name 
FROM sys.check_constraints i 
JOIN sys.objects o on i.parent_object_id = o.object_id 
JOIN sys.schemas s on o.schema_id = s.schema_id 
WHERE i.is_not_trusted = 1 
AND i.is_not_for_replication = 0
 Check Constraint Check... Will build the statement below to CHECK (validate) the check constraints for those check constraints that are untrusted.
*/

/*
set nocount on

select 'use [' + db_name() + ']'
select 'go'

select 'ALTER TABLE ' + s.name + '.' + OBJECT_NAME(o.object_id) + ' WITH CHECK CHECK CONSTRAINT ' + i.name + '
GO'
FROM sys.foreign_keys i  INNER JOIN sys.objects o ON i.parent_object_id = o.object_id INNER JOIN sys.schemas s ON o.schema_id = s.schema_id WHERE i.is_not_trusted = 1 AND i.is_not_for_replication = 0
-- Foreign Key Check... Will build the statement below to CHECK (validate) the FK for those FK's that are untrusted.
UNION
select 'ALTER TABLE ' +  s.name + '.' + OBJECT_NAME(o.object_id) + ' WITH CHECK CHECK CONSTRAINT ' + i.name + '
GO'
from sys.check_constraints i join sys.objects o on i.parent_object_id = o.object_id join sys.schemas s on o.schema_id = s.schema_id where i.is_not_trusted = 1 and i.is_not_for_replication = 0
-- Check Constraint Check... Will build the statement below to CHECK (validate) the check constraints for those check constraints that are untrusted.


-- !!!! -- The output (in TEXT) will look similar to what you see below.  once you have the output, put it into the query window and execute it.
*/

