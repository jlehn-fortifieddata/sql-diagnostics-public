/*============================================================================
  File:     Memory Cache Store

  Summary:  Provides real time results for the current processes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SELECT TOP 100 @@SERVERNAME AS [Server Name] 
	, (CASE WHEN ([database_id] = 32767)
        THEN 'Resource Database'
        ELSE DB_NAME ([database_id]) END) AS [DatabaseName],
    COUNT (*) * 8 / 1024 AS [MBUsed],
    SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024) AS [MBEmpty]
 FROM sys.dm_os_buffer_descriptors
 GROUP BY [database_id];
 
/*
-- Plan cache is currently allocated
SELECT @@SERVERNAME AS [Server Name] 
	, db_name() AS [DB Name]
	, objtype AS [CacheType]
	, count_big(*) AS [Total Plans]
	, sum(cast(size_in_bytes as decimal(18,2)))/1024/1024 AS [Total MBs]
	, avg(CAST(usecounts AS BIGINT)) AS [Avg Use Count]
	, sum(cast((CASE WHEN usecounts = 1 THEN size_in_bytes ELSE 0 END) as decimal(18,2)))/1024/1024 AS [Total MBs - USE Count 1]
	, sum(CASE WHEN usecounts = 1 THEN 1 ELSE 0 END) AS [Total Plans - USE Count 1]
FROM sys.dm_exec_cached_plans
GROUP BY objtype
ORDER BY [Total MBs - USE Count 1] DESC
*/
--IF (SELECT CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('PRODUCTVERSION') AS CHAR(1)), 1, 1) IN (9) THEN 1 ELSE 0 END) = 1
--BEGIN
--	SELECT SUM(single_pages_kb + multi_pages_kb) AS 
--	   "CurrentSizeOfTokenCache(kb)" 
--	   FROM sys.dm_os_memory_clerks 
--	   WHERE name = 'TokenAndPermUserStore'
--END
   
-- Total Plans in cache
--SELECT cp.objtype, cp.cacheobjtype, cp.size_in_bytes, cp.refcounts, cp.usecounts, st.text
--FROM sys.dm_exec_cached_plans AS cp
--CROSS apply sys.dm_exec_sql_text(cp.plan_handle)AS st
--WHERE cp.objtype IN('Adhoc', 'Prepared')
----        AND st.text LIKE '%from dbo.member%' 
----        AND st.text NOT LIKE '%SELECT cp.objecttype%'
--ORDER BY cp.objtype


---- WHERE USECOUNT < 10
--SELECT cp.objtype, cp.cacheobjtype, cp.size_in_bytes, cp.refcounts, cp.usecounts, st.text
--FROM sys.dm_exec_cached_plans AS cp
--CROSS apply sys.dm_exec_sql_text(cp.plan_handle)AS st
--WHERE cp.objtype IN('Adhoc', 'Prepared')
----        AND st.text LIKE '%from dbo.member%' 
----        AND st.text NOT LIKE '%SELECT cp.objecttype%'
--and usecounts < 10
--ORDER BY cp.objtype
--go

---- where UseCount >= 10
--SELECT cp.objtype, cp.cacheobjtype, cp.size_in_bytes, cp.refcounts, cp.usecounts, st.text
--FROM sys.dm_exec_cached_plans AS cp
--CROSS apply sys.dm_exec_sql_text(cp.plan_handle)AS st
--WHERE cp.objtype IN('Adhoc', 'Prepared')
----        AND st.text LIKE '%from dbo.member%' 
----        AND st.text NOT LIKE '%SELECT cp.objecttype%'
--and usecounts >= 10
--ORDER BY cp.objtype
--go