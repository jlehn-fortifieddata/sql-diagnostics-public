/*============================================================================
  File:     Log - Errorlog - Dump and Filter Health

  Summary:  Reads the SQL Server error log and searches it for phrases.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

CREATE TABLE #temp
	(logdate DATETIME,
	processinfo VARCHAR(100),
	logtext VARCHAR(max))

INSERT #temp
EXEC sp_readerrorlog 0, NULL, 3--, 'deadlock'

INSERT #temp
EXEC sp_readerrorlog 1, NULL, 3--, 'deadlock'


CREATE INDEX idx1 ON #temp(processinfo)


--FILTER OUT NOISE TO DETERMINE THE ATYPICAL ERRORS
SELECT @@SERVERNAME AS [Server Name]
	, logtext AS [AllErrors_SQLLog]
	, MIN(logdate) AS 'Min Logdate'
	, MAX(logdate) AS 'Max Logdate'
	, COUNT(*) [Count]
FROM #temp
WHERE logtext NOT LIKE '%SQL Trace%'
AND logtext NOT LIKE '%log was%'
AND logtext NOT LIKE '%database backed%'
AND logtext NOT LIKE '%frame procname%'
AND logtext NOT LIKE '%owner%'
AND logtext NOT LIKE '%waiter id%'
AND logtext NOT LIKE '%differential%'
AND logtext NOT LIKE '%backupmedium%'
AND logtext NOT LIKE '%backupvirtual%'
AND logtext NOT LIKE '%0 transactions%'
AND logtext NOT LIKE '%starting%'
AND logtext NOT LIKE '%setting database%'
AND logtext NOT LIKE '%checkdb%'
AND logtext NOT LIKE '%restore%'
AND logtext NOT LIKE '%the client was%'
AND logtext NOT LIKE '%analysis of%'
GROUP BY logtext
ORDER BY 5 DESC

-- FILTER ON ANONYMOUS LOGON
SELECT @@SERVERNAME AS [Server Name]
	, logtext AS [AllErrors_SQLLog]
	, MIN(logdate) AS 'Min Logdate'
	, MAX(logdate) AS 'Max Logdate'
	, COUNT(*) [Count]
FROM #temp
WHERE logtext LIKE '%NT AUTHORITY\ANONYMOUS LOGON%'
GROUP BY logtext
ORDER BY 5 DESC

drop table #temp

-- SHOW RECORDS RIGHT BEFORE AND AFTER THE SEARCH PHRASE
SELECT @@SERVERNAME AS [Server Name]
	, logtext AS [IOErrors_SQLLog]
	, MIN(logdate) AS 'Min Logdate'
	, MAX(logdate) AS 'Max Logdate'
	, COUNT(*) [Count]
FROM #temp
WHERE logtext like '%i/o%'
GROUP BY logtext
ORDER BY 5 DESC

DROP TABLE #temp

/*
CREATE TABLE #SQLErrorLog
(Recorded DATETIME NULL,
ProcessInfo VARCHAR(20) NULL,
Msg VARCHAR(MAX) NULL ) ;
 
INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 1;

DELETE FROM #SQLErrorLog where Msg like 'Log was backed up. Database%' or Msg in ('All rights reserved.', '(c) Microsoft Corporation.', 'Service Broker manager has started.', 'Clearing tempdb database.', 'Authentication mode is MIXED.', 'The Service Broker endpoint is in disabled or stopped state.', 'The Database Mirroring endpoint is in disabled or stopped state.', 'Using dynamic lock allocation.  Initial allocation of 2500 Lock blocks and 5000 Lock Owner blocks per node.  This is an informational message only.  No user action is required.', 'A self-generated certificate was successfully loaded for encryption.', 'A new instance of the full-text filter daemon host process has been successfully started.', 'Recovery is complete. This is an informational message only. No user action is required.', 'SQL Server Audit has started the audits. This is an informational message. No user action is required.', 'SQL Server Audit is starting the audits. This is an informational message. No user action is required.', 'SQL Server is starting at normal priority base (=7). This is an informational message only. No user action is required.') 
or Msg like 'Microsoft SQL Server 20%Copyright (c) Microsoft Corporation%' or Msg like 'Server is listening on%' or Msg like 'Restore is complete on database%' or Msg like 'Recovery is writing a checkpoint in database%'
or Msg like 'Error: 18456, Severity: 14%' or Msg like 'Login failed for user%' or Msg like 'BACKUP DATABASE successfully processed%' or Msg like 'Database backed up. Database%' or Msg = 'Configuration option ''xp_cmdshell'' changed from 1 to 1. Run the RECONFIGURE statement to install.'
or Msg = 'Configuration option ''show advanced options'' changed from 1 to 1. Run the RECONFIGURE statement to install.' or Msg like 'This instance of SQL Server has been using a process ID of % This is an informational message only; no user action is required.'
or Msg like '% This is an informational message only; no user action is required.' or Msg like 'Attempting to load library % into memory. This is an informational message only. No user action is required.'
or Msg like 'Setting database option %' or Msg like 'Starting up database%' or Msg like 'DBCC CHECKDB %found 0 errors and repaired 0 errors. %' or Msg like 'Server process ID is%' or Msg like 'System Manufacturer:%'
or Msg like 'Logging SQL Server messages in file%' or Msg like '%This is an informational message; no user action is required.' or Msg like 'CLR version%' or Msg like 'Recovery completed for database%'
or Msg like '% transactions rolled%' or Msg like 'Server local connection provider is ready to accept connection on %' or Msg like 'RESTORE DATABASE successfully processed %'
or Msg like 'Database was restored: Database:%' or Msg like 'SQL Trace stopped. Trace ID = %' or Msg like 'SQL Trace ID % was started by login %' or Msg like 'SQL Server Audit has started the audits. This is an informational message. No user action is required.'
or Msg like 'The resource database build version is %. This is an informational message only. No user action is required.' or Msg like 'Dedicated admin connection support was established for listening locally on port %'
or Msg like 'Common language runtime (CLR) functionality initialized using CLR version %' or Msg like 'Server name is %. This is an informational message only. No user action is required.'
or Msg like 'Node configuration: node %. This message provides a description of the NUMA configuration for this computer. This is an informational message only. No user action is required.'

SELECT * FROM #SQLErrorLog

drop table #SQLErrorLog 

SELECT * FROM sys.databases

*/

/*
--DEFAULT TRACE INFO
declare @dftrc nvarchar(520)
select @dftrc = path from sys.traces

select [name], count(eventclass)
from ::fn_trace_gettable(@dftrc, default) a
join sys.trace_events b on (a.eventclass = b.trace_event_id)
group by name
order by 2 desc

select name, a.*
from ::fn_trace_gettable(@dftrc, default) a
join sys.trace_events b on (a.eventclass = b.trace_event_id)
where name = 'ErrorLog'


--ERROR LOG INFO
SET NOCOUNT ON

IF (SELECT object_id('TempDB..#SQLErrorLog')) is not null
BEGIN
                PRINT 'Dropped #SQLErrorLog...'
                DROP TABLE #SQLErrorLog
END

PRINT 'Created #SQLErrorLog...'
CREATE TABLE #SQLErrorLog
(Recorded DATETIME NULL,
ProcessInfo VARCHAR(20) NULL,
Msg VARCHAR(MAX) NULL ) ;

PRINT 'Adding log data to #SQLErrorLog...'
INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 0;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 1;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 2;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 3;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 4;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 5;

INSERT INTO #SQLErrorLog (Recorded, ProcessInfo, Msg)
EXEC master.dbo.xp_readerrorlog 6;

PRINT 'Deleting noise from #SQLErrorLog...'
DELETE FROM #SQLErrorLog where Msg like 'Log was backed up. Database%' or Msg in ('All rights reserved.', '(c) Microsoft Corporation.', 'Service Broker manager has started.', 'Clearing tempdb database.', 'Authentication mode is MIXED.', 'The Service Broker endpoint is in disabled or stopped state.', 'The Database Mirroring endpoint is in disabled or stopped state.', 'Using dynamic lock allocation.  Initial allocation of 2500 Lock blocks and 5000 Lock Owner blocks per node.  This is an informational message only.  No user action is required.', 'A self-generated certificate was successfully loaded for encryption.', 'A new instance of the full-text filter daemon host process has been successfully started.', 'Recovery is complete. This is an informational message only. No user action is required.', 'SQL Server Audit has started the audits. This is an informational message. No user action is required.', 'SQL Server Audit is starting the audits. This is an informational message. No user action is required.', 'SQL Server is starting at normal priority base (=7). This is an informational message only. No user action is required.') 
or Msg like 'Microsoft SQL Server 20%Copyright (c) Microsoft Corporation%' or Msg like 'Server is listening on%' or Msg like 'Restore is complete on database%' or Msg like 'Recovery is writing a checkpoint in database%'
or Msg like 'Error: 18456, Severity: 14%' or Msg like 'Login failed for user%' or Msg like 'BACKUP DATABASE successfully processed%' or Msg like 'Database backed up. Database%' or Msg = 'Configuration option ''xp_cmdshell'' changed from 1 to 1. Run the RECONFIGURE statement to install.'
or Msg = 'Configuration option ''show advanced options'' changed from 1 to 1. Run the RECONFIGURE statement to install.' or Msg like 'This instance of SQL Server has been using a process ID of % This is an informational message only; no user action is required.'
or Msg like '% This is an informational message only; no user action is required.' or Msg like 'Attempting to load library % into memory. This is an informational message only. No user action is required.'
or Msg like 'Setting database option %' or Msg like 'Starting up database%' or Msg like 'DBCC CHECKDB %found 0 errors and repaired 0 errors. %' or Msg like 'Server process ID is%' or Msg like 'System Manufacturer:%'
or Msg like 'Logging SQL Server messages in file%' or Msg like '%This is an informational message; no user action is required.' or Msg like 'CLR version%' or Msg like 'Recovery completed for database%'
or Msg like '% transactions rolled%' or Msg like 'Server local connection provider is ready to accept connection on %' or Msg like 'RESTORE DATABASE successfully processed %'
or Msg like 'Database was restored: Database:%' or Msg like 'SQL Trace stopped. Trace ID = %' or Msg like 'SQL Trace ID % was started by login %' or Msg like 'SQL Server Audit has started the audits. This is an informational message. No user action is required.'
or Msg like 'The resource database build version is %. This is an informational message only. No user action is required.' or Msg like 'Dedicated admin connection support was established for listening locally on port %'
or Msg like 'Common language runtime (CLR) functionality initialized using CLR version %' or Msg like 'Server name is %. This is an informational message only. No user action is required.'
or Msg like 'Node configuration: node %. This message provides a description of the NUMA configuration for this computer. This is an informational message only. No user action is required.'

SET NOCOUNT OFF

SELECT * FROM #SQLErrorLog

*/