CREATE TABLE #tmptest(
	DBName sysname,
	[schema_name] [nvarchar](128) NULL,
	[table_name] [sysname] NOT NULL,
	[type_desc] [nvarchar](60) NULL,
	[index_or_statistics_name] [nvarchar](128) NULL,
	[is_auto_stats] [bit] NULL,
	[user_created] [bit] NULL,
	[last_updated] [datetime] NULL,
	[ROW_count] [bigint] NULL)

declare @tsql nvarchar(max)
declare @dbname sysname 

declare db cursor for 
select name from sys.databases where database_id > 4  order by name
open db; 

fetch next from db into @dbname 
while @@FETCH_STATUS = 0 
begin

set @tsql = 'USE ['+ @dbname + '];
INSERT #tmptest 
SELECT  
		'+ ''''+@dbname+'''' + ',
		[schema_name] = sch.name,
        table_name = T.name,        
        T.type_desc,
        index_or_statistics_name = S.name,
        is_auto_stats = S.auto_created,
        user_created = S.user_created,
        last_updated = STATS_DATE(T.[object_id], S.stats_id) , cast(0 as bigint) as ROW_count 
FROM    [' + @dbname + '].sys.tables T
JOIN	[' + @dbname + '].sys.schemas sch on T.schema_id = sch.schema_id
JOIN    [' + @dbname + '].sys.stats S
        ON  S.[object_id] = T.[object_id]
ORDER   BY
        T.[schema_id],
        T.name,
        S.stats_id
	
update #tmptest 
set ROW_count = (select a.rows 
				 from 
					(SELECT OBJECT_NAME(P.object_id) AS [Name], 
					 sum(P.rows) as rows, 
					 ' + ''''+@dbname+''''+' as DBNAME 
					 FROM [' + @dbname + '].sys.indexes I
					 INNER JOIN [' + @dbname + '].sys.partitions P 
						ON P.object_id = I.object_id AND P.index_id = I.index_id
					 WHERE I.index_id < 2 and #tmptest.dbname = '+''''+@dbname+''''+' 
					 group by OBJECT_NAME(P.object_id) ) a 
				 where a.Name = #tmptest.table_name and a.DBNAME = '+''''+@dbname+''''+')
where #tmptest.dbname = '+''''+@dbname+''''+' 
option (recompile) ; '

	exec	sp_executesql  @tsql;

fetch next from db into @dbname ;
end 
close db;
deallocate db;


select * from #tmptest where row_count > 1
order by last_updated;
 
drop table #tmptest