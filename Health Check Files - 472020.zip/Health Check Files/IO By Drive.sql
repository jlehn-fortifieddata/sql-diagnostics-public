/*============================================================================
  File:     IO By Drive

  Summary:  Provides IO stall data.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SET NOCOUNT ON

	SELECT 	@@SERVERNAME AS [Server Name]
		, SUBSTRING(physical_name, 1, 1) AS [drive]
		, SUM(io_stall_read_ms) AS io_stall_read_ms
		, SUM(num_of_reads) AS num_of_reads
		, SUM(num_of_bytes_read) AS num_of_bytes_read
		, AVG(CAST(io_stall_read_ms/(1.0+num_of_reads) AS NUMERIC(10,1))) AS 'avg_read_stall_ms'
		, SUM(io_stall_write_ms) AS [io_stall_write_ms]
		, SUM(num_of_writes) AS num_of_writes
		, SUM(num_of_bytes_written) AS num_of_bytes_written
		, AVG(CAST(io_stall_write_ms/(1.0+num_of_writes) AS NUMERIC(10,1))) AS 'avg_write_stall_ms'
		, SUM(io_stall_read_ms + io_stall_write_ms) AS io_stalls
		, SUM(num_of_reads + num_of_writes) AS total_io
		, AVG(CAST((io_stall_read_ms+io_stall_write_ms)/(1.0+num_of_reads + num_of_writes) AS NUMERIC(10,1))) AS 'avg_io_stall_ms'
	FROM sys.dm_io_virtual_file_stats(null,null) fs
	JOIN sys.master_files f on fs.database_id = f.database_id and fs.file_id = f.[file_id]
	GROUP BY SUBSTRING(physical_name, 1, 1)
	--order by avg_io_stall_ms desc
