/*============================================================================
  File:     Top X by Logical Writes per min

  Summary:  Provides the TOP X statements based upond total logical writes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Get Top 20 executed SP's ordered by logical writes/minute
SELECT TOP 100 
		@@SERVERNAME 'Server Name'
		, COALESCE(DB_NAME(qt.dbid),'Unknown') AS [DB Name]
		, CAST(substring(qt.text, (qs.statement_start_offset/2)+1
                , ((case qs.statement_end_offset
                      when -1 then datalength(qt.text)
                      else qs.statement_end_offset
                   end - qs.statement_start_offset)/2) + 1)AS VARCHAR(1000))  as Statement
	, qs.total_logical_writes
	, qs.total_logical_writes/qs.execution_count AS 'AvgLogicalWrites'
	, qs.total_logical_writes/DATEDIFF(Minute, qs.creation_time, GetDate()) AS 'Logical Writes/Min'
	, qs.execution_count AS 'Execution Count'
	, qs.execution_count/DATEDIFF(Second, qs.creation_time, GetDate()) AS 'Calls/Second'
	, qs.total_worker_time/qs.execution_count AS 'AvgWorkerTime'
	, qs.total_worker_time AS 'TotalWorkerTime'
	, qs.total_elapsed_time/qs.execution_count AS 'AvgElapsedTime'
	, qs.max_logical_reads, qs.max_logical_writes, qs.total_physical_reads
	, DATEDIFF(Minute, qs.creation_time, GetDate()) AS 'Age in Cache'
	, qs.total_physical_reads/qs.execution_count AS 'Avg Physical Reads'
	, qt.dbid
	, DATEDIFF(Minute, qs.creation_time, GetDate()) AS 'Age in Cache', qt.dbid 
	, CAST(qt.text AS VARCHAR(1000))   AS 'SPText'
	, GETDATE() AS 'RunTime'
	--, (
 --       SELECT          
	--		substring(text, (statement_start_offset/2)+1
 --               , ((case statement_end_offset
 --                     when -1 then datalength(text)
 --                     else statement_end_offset
 --                  end - statement_start_offset)/2) + 1)
 --       FROM sys.dm_exec_sql_text(qs.sql_handle)
 --       FOR XML PATH(''), TYPE
 --   ) AS statement_text
	--, (SELECT text
	--	FROM sys.dm_exec_sql_text(qs.sql_handle) AS qt
	--	FOR XML PATH(''), TYPE) 'SPTextFMT'
	--, query_plan
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY SYS.dm_exec_query_plan(qs.plan_handle) AS qp
WHERE qt.dbid != 32767
--where qt.dbid != 7
--where substring(qt.text, (qs.statement_start_offset/2)+1
--                , ((case qs.statement_end_offset
--                      when -1 then datalength(qt.text)
--                      else qs.statement_end_offset
--                   end - qs.statement_start_offset)/2) + 1) like '%#history%'

ORDER BY qs.total_logical_writes DESC