/*============================================================================
  File:     Server Audit Report

  Summary:  Displays information about the server.
  
  Date:     2008

  Versions: !!!!!!!!!!2005, 2008 is on the bottom.!!!!!!!!!!!!!!
			Requires KT's 2005 and 2008 modified index scripts.
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


USE master
SET NOCOUNT ON

DECLARE @vcMessage         VARCHAR(100)
DECLARE @vcServerName      VARCHAR(30)
DECLARE @sqlcmd NVARCHAR(MAX)


SELECT  @@SERVERNAME AS [Server Name]
	, SERVERPROPERTY('MachineName') as 'Virtual Name' 
	, SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as 'Physical Name'
	, SERVERPROPERTY('productversion') as 'Product Version' 
	, SERVERPROPERTY('productlevel') as 'Product Level'  
	, SERVERPROPERTY('edition') as 'Product Edition'
	, [ProductVersionDesc] = CASE SERVERPROPERTY('ProductVersion') 
		WHEN '11.0.5058.0' THEN 'SQL Server 2012 SP2'
		WHEN '11.0.3431.0' THEN 'SQL Server 2012 SP1 CU10'
		WHEN '11.0.3412.0' THEN 'SQL Server 2012 SP1 CU9'
		WHEN '11.0.3401.0' THEN 'SQL Server 2012 SP1 CU8'
		WHEN '11.0.3393.0' THEN 'SQL Server 2012 SP1 CU7'
		WHEN '11.0.3381.0' THEN 'SQL Server 2012 SP1 CU6'
		WHEN '11.0.3373.0' THEN 'SQL Server 2012 SP1 CU5'
		WHEN '11.0.3368.0' THEN 'SQL Server 2012 SP1 CU4'
		WHEN '11.0.3349.0' THEN 'SQL Server 2012 SP1 CU3'
		WHEN '11.0.3339.0' THEN 'SQL Server 2012 SP1 CU2'
		WHEN '11.0.3321.0' THEN 'SQL Server 2012 SP1 CU1'
		WHEN '11.0.3000.0' THEN 'SQL Server 2012 SP1'
		WHEN '11.0.2424.0' THEN 'SQL Server 2012 CU11'
		WHEN '11.0.2420.0' THEN 'SQL Server 2012 CU10'
		WHEN '11.0.2419.0' THEN 'SQL Server 2012 CU9'
		WHEN '11.0.2410.0' THEN 'SQL Server 2012 CU8'
		WHEN '11.0.2405.0' THEN 'SQL Server 2012 CU7'
		WHEN '11.0.2401.0' THEN 'SQL Server 2012 CU6'
		WHEN '11.0.2395.0' THEN 'SQL Server 2012 CU5'
		WHEN '11.0.3350.0' THEN 'SQL Server 2012 CU4'
		WHEN '11.0.2383.0' THEN 'SQL Server 2012 CU4'
		WHEN '11.0.2332.0' THEN 'SQL Server 2012 CU3'
		WHEN '11.0.2325.0' THEN 'SQL Server 2012 CU2'
		WHEN '11.0.2316.0' THEN 'SQL Server 2012 CU1'
		WHEN '10.0.1600.22' THEN 'SQL Server 2012 RTM'
		WHEN '10.50.2811.0' THEN 'SQL Server 2008 R2 SP1 CU6'
		WHEN '10.50.2806.0' THEN 'SQL Server 2008 R2 SP1 CU5'
		WHEN '10.50.2796.0' THEN 'SQL Server 2008 R2 SP1 CU4'
		WHEN '10.50.2789.0' THEN 'SQL Server 2008 R2 SP1 CU3'
		WHEN '10.50.2772.0' THEN 'SQL Server 2008 R2 SP1 CU2'
		WHEN '10.50.2769.0' THEN 'SQL Server 2008 R2 SP1 CU1'
		WHEN '10.50.2500.0' THEN 'SQL Server 2008 R2 SP1'
		WHEN '10.50.1815' THEN 'SQL Server 2008 R2 CU13'
		WHEN '10.50.1810' THEN 'SQL Server 2008 R2 CU12'
		WHEN '10.50.1809' THEN 'SQL Server 2008 R2 CU11'
		WHEN '10.50.1807.0' THEN 'SQL Server 2008 R2 CU10'
		WHEN '10.50.1804.0' THEN 'SQL Server 2008 R2 CU9'
		WHEN '10.50.1797.0' THEN 'SQL Server 2008 R2 CU8'
		WHEN '10.50.1777.0' THEN 'SQL Server 2008 R2 CU7'
		WHEN '10.50.1765.0' THEN 'SQL Server 2008 R2 CU6'
		WHEN '10.50.1753.0' THEN 'SQL Server 2008 R2 CU5'
		WHEN '10.50.1746.0' THEN 'SQL Server 2008 R2 CU4'
		WHEN '10.50.1734.0' THEN 'SQL Server 2008 R2 CU3'
		WHEN '10.50.1720.0' THEN 'SQL Server 2008 R2 CU2'
		WHEN '10.50.1702.0' THEN 'SQL Server 2008 R2 CU1'
		WHEN '10.50.1600.1' THEN 'SQL Server 2008 R2 RTM'
		WHEN '10.00.5775' THEN 'SQL Server 2008 SP3 CU4'
		WHEN '10.00.5770' THEN 'SQL Server 2008 SP3 CU3'
		WHEN '10.00.5768' THEN 'SQL Server 2008 SP3 CU2'
		WHEN '10.00.5766' THEN 'SQL Server 2008 SP3 CU1'
		WHEN '10.00.5500' THEN 'SQL Server 2008 SP3'
		WHEN '10.00.4330' THEN 'SQL Server 2008 SP2 CU9'
		WHEN '10.00.4326' THEN 'SQL Server 2008 SP2 CU8'
		WHEN '10.00.4323' THEN 'SQL Server 2008 SP2 CU7'
		WHEN '10.00.4321' THEN 'SQL Server 2008 SP2 CU6'
		WHEN '10.00.4316' THEN 'SQL Server 2008 SP2 CU5'
		WHEN '10.00.4285' THEN 'SQL Server 2008 SP2 CU4'
		WHEN '10.00.4279' THEN 'SQL Server 2008 SP2 CU3'
		WHEN '10.00.4272' THEN 'SQL Server 2008 SP2 CU2'
		WHEN '10.00.4266' THEN 'SQL Server 2008 SP2 CU1'
		WHEN '10.00.4000' THEN 'SQL Server 2008 SP2'
		WHEN '10.00.2850' THEN 'SQL Server 2008 SP1 CU16'
		WHEN '10.00.2847' THEN 'SQL Server 2008 SP1 CU15'
		WHEN '10.00.2816' THEN 'SQL Server 2008 SP1 CU13'
		WHEN '10.00.2812' THEN 'SQL Server 2008 SP1 CU14'
		WHEN '10.00.2808' THEN 'SQL Server 2008 SP1 CU12'
		WHEN '10.00.2804' THEN 'SQL Server 2008 SP1 CU11'
		WHEN '10.00.2799' THEN 'SQL Server 2008 SP1 CU10'
		WHEN '10.00.2789' THEN 'SQL Server 2008 SP1 CU9'
		WHEN '10.00.2775' THEN 'SQL Server 2008 SP1 CU8'
		WHEN '10.00.2766' THEN 'SQL Server 2008 SP1 CU7'
		WHEN '10.00.27.57.00' THEN 'SQL Server 2008 SP1 CU6'
		WHEN '10.00.2746.00' THEN 'SQL Server 2008 SP1 CU5'
		WHEN '10.00.2734.00' THEN 'SQL Server 2008 SP1 CU4'
		WHEN '10.00.2723.00' THEN 'SQL Server 2008 SP1 CU3'
		WHEN '10.00.2714.00' THEN 'SQL Server 2008 SP1 CU2'
		WHEN '10.00.2710.00' THEN 'SQL Server 2008 SP1 CU1'
		WHEN '10.00.2531.00' THEN 'SQL Server 2008 SP1'
		WHEN '10.00.1828.00' THEN 'SQL Server 2008 RTM CU9'
		WHEN '10.00.1823.00' THEN 'SQL Server 2008 RTM CU8'
		WHEN '10.00.1818.00' THEN 'SQL Server 2008 RTM CU7'
		WHEN '10.00.1812.00' THEN 'SQL Server 2008 RTM CU6'
		WHEN '10.00.1806.00' THEN 'SQL Server 2008 RTM CU5'
		WHEN '10.00.1798.00' THEN 'SQL Server 2008 RTM CU4'
		WHEN '10.00.1787.00' THEN 'SQL Server 2008 RTM CU3'
		WHEN '10.00.1779.00' THEN 'SQL Server 2008 RTM CU2'
		WHEN '10.00.1763.00' THEN 'SQL Server 2008 RTM CU1'
		WHEN '10.00.1600.00' THEN 'SQL Server 2008 RTM'
		WHEN '9.00.4285.00' THEN 'SQL Server 2005 SP3 CU8'
		WHEN '9.00.4273.00' THEN 'SQL Server 2005 SP3 CU7'
		WHEN '9.00.4266.00' THEN 'SQL Server 2005 SP3 CU6'
		WHEN '9.00.4230.00' THEN 'SQL Server 2005 SP3 CU5'
		WHEN '9.00.4226.00' THEN 'SQL Server 2005 SP3 CU4'
		WHEN '9.00.4220.00' THEN 'SQL Server 2005 SP3 CU3'
		WHEN '9.00.4211.00' THEN 'SQL Server 2005 SP3 CU2'
		WHEN '9.00.4207.00' THEN 'SQL Server 2005 SP3 CU1'
		WHEN '9.00.4053.00' THEN 'SQL Server 2005 SP3 GDR�(Security Update)'
		WHEN '9.00.4035.00' THEN 'SQL Server 2005 SP3'
		WHEN '9.00.3356.00' THEN 'SQL Server 2005 SP2 CU17'
		WHEN '9.00.3355.00' THEN 'SQL Server 2005 SP2 CU16'
		WHEN '9.00.3330.00' THEN 'SQL Server 2005 SP2 CU15'
		WHEN '9.00.3328.00' THEN 'SQL Server 2005 SP2 CU14'
		WHEN '9.00.3225.00' THEN 'SQL Server 2005 SP2 CU13'
		WHEN '9.00.3315.00' THEN 'SQL Server 2005 SP2 CU12'
		WHEN '9.00.3310.00' THEN 'SQL Server 2005 Security Update'
		WHEN '9.00.3301.00' THEN 'SQL Server 2005 SP2 CU11'
		WHEN '9.00.3294.00' THEN 'SQL Server 2005 SP2 CU10'
		WHEN '9.00.3282.00' THEN 'SQL Server 2005 SP2 CU9'
		WHEN '9.00.3257.00' THEN 'SQL Server 2005 SP2 CU8'
		WHEN '9.00.3239.00' THEN 'SQL Server 2005 SP2 CU7'
		WHEN '9.00.3233.00' THEN 'SQL Server 2005 QFE Security Update'
		WHEN '9.00.3228.00' THEN 'SQL Server 2005 SP2 CU6'
		WHEN '9.00.3215.00' THEN 'SQL Server 2005 SP2 CU5'
		WHEN '9.00.3200.00' THEN 'SQL Server 2005 SP2 CU4'
		WHEN '9.00.3186.00' THEN 'SQL Server 2005 SP2 CU3'
		WHEN '9.00.3175.00' THEN 'SQL Server 2005 SP2 CU2'
		WHEN '9.00.3161.00' THEN 'SQL Server 2005 SP2 Cumulative Update 1 (CU1)'
		WHEN '9.00.3152.00' THEN 'SQL Server 2005 SP2 Cumulative Hotfix'
		WHEN '9.00.3077.00' THEN 'SQL Server 2005 Security Update'
		WHEN '9.00.3054.00' THEN 'KB934458�- Also read�Bob Ward''s post on SP2.'
		WHEN '9.00.3042.01.00' THEN 'SQL Server 2005 "SP2a"'
		WHEN '9.00.3042.00' THEN 'SQL Server 2005 SP2'
		WHEN '9.00.2047.00' THEN 'SQL Server 2005 SP1'
		WHEN '9.00.1399.00' THEN 'SQL Server 2005 RTM'
		WHEN '8.00.2039.00' THEN 'SQL Server 2000 SP4'
		WHEN '8.00.760.00' THEN 'SQL Server 2000 SP3'
		WHEN '8.00.534.00' THEN 'SQL Server 2000 SP2'
		WHEN '8.00.384.00' THEN 'SQL Server 2000 SP1'
		WHEN '8.00.194.00' THEN 'SQL Server 2000 RTM'
		WHEN '7.00.1063.00' THEN 'SQL Server 7.0 SP4'
		WHEN '7.00.961.00' THEN 'SQL Server 7.0 SP3'
		WHEN '7.00.842.00' THEN 'SQL Server 7.0 SP2'
		WHEN '7.00.699.00' THEN 'SQL Server 7.0 SP1'
		WHEN '7.00.623.00' THEN 'SQL Server 7.0 / MSDE 1.0 RTM'
		WHEN '6.50.416.00' THEN 'SQL Server 6.5 with Service Pack 5a'
		WHEN '6.50.415.00' THEN 'SQL Server 6.5 with Service Pack 5'
		WHEN '6.50.281.00' THEN 'SQL Server 6.5 with Service Pack 4'
		WHEN '6.50.258.00' THEN 'SQL Server 6.5 with Service Pack 3'
		WHEN '6.50.240.00' THEN 'SQL Server 6.5 with Service Pack 2'
		WHEN '6.50.213.00' THEN 'SQL Server 6.5 with Service Pack 1'
		WHEN '6.50.201.00' THEN 'SQL Server 6.5 RTM'
		ELSE 'Other'
	END
	, [ProductVersion] = SERVERPROPERTY('ProductVersion')
	, SERVERPROPERTY('buildclrversion') as 'CLR Version'
	, SERVERPROPERTY('instancename') as 'Instance'
	, SERVERPROPERTY('lcid') as 'LCID'
	, CONVERT(char(50), SERVERPROPERTY('Collation')) as "Collation"
	, CONVERT(char(50), SERVERPROPERTY('Edition'))  as "DB Edition"
	, ISNULL(CONVERT(char(20), SERVERPROPERTY('InstanceName')), 'Default') as "Instance Name"
	, CONVERT(char(20), SERVERPROPERTY('LicenseType')) as "Licence Type"
	, ISNULL(CONVERT(char(20), SERVERPROPERTY('NumLicenses')), 'N/A') as "Number of Licences"
	, CONVERT(char(20), SERVERPROPERTY('ProcessID')) as "SQL Server Process ID"
	,  IsClustered =
       CASE SERVERPROPERTY('IsClustered') 
            WHEN 0 THEN 'NO'
            WHEN 1 THEN 'YES'
       END
	, IsFullTextInstalled =
       CASE SERVERPROPERTY('IsFullTextInstalled') 
            WHEN 0 THEN 'NO'
            WHEN 1 THEN 'YES'
       END
	, IsIntegratedSecurityOnly =
       CASE SERVERPROPERTY('IsIntegratedSecurityOnly') 
            WHEN 0 THEN 'NO'
            WHEN 1 THEN 'YES'
       END
	, IsSingleUser =
       CASE SERVERPROPERTY('IsSingleUser') 
            WHEN 0 THEN 'NO'
            WHEN 1 THEN 'YES'
       END

-- Windows information (SQL Server 2012)  (Query 4)
SELECT windows_release, windows_service_pack_level, 
       windows_sku, os_language_version
FROM sys.dm_os_windows_info WITH (NOLOCK) OPTION (RECOMPILE);

-- Display all enable trace flags
DBCC TRACESTATUS()

-- Server CPU and Core information
IF (SELECT CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('PRODUCTVERSION') AS CHAR(2)), 1, 1) IN ('9.', '10') THEN 1 ELSE 0 END) = 1
BEGIN

	SET @sqlcmd = 'SELECT  @@SERVERNAME AS [Server Name]
		, cpu_count AS [Logical CPU Count]
		, hyperthread_ratio AS [Hyperthread Ratio]
		, cpu_count/hyperthread_ratio AS [Physical CPU Count]
		, physical_memory_in_bytes/1048576 AS [Physical Memory (MB)]
		, (SELECT value_in_use
			FROM sys.configurations
			WHERE name = ''max server memory (MB)'') [SQL Max Memory]
	FROM sys.dm_os_sys_info --OPTION (RECOMPILE)'

	EXEC SP_EXECUTESQL @sqlcmd
		
END

-- Server CPU and Core information
IF (SELECT CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('PRODUCTVERSION') AS CHAR(2)), 1, 1) IN (11) THEN 1 ELSE 0 END) = 1
BEGIN

	-- SQL REGISTRY INFORMATION
	SELECT * 
	FROM sys.dm_server_registry
	ORDER BY 2
	
	SELECT servicename
		, process_id
		, startup_type_desc
		, status_desc
		, last_startup_time
		, service_account
		, is_clustered
		, cluster_nodename
		, [filename]
	FROM sys.dm_server_services WITH (NOLOCK) OPTION (RECOMPILE);

	SET @sqlcmd = 'SELECT @@SERVERNAME AS [Server Name]
		, cpu_count AS [Logical CPU Count]
		, scheduler_count
		, hyperthread_ratio AS [Hyperthread Ratio]
		, cpu_count/hyperthread_ratio AS [Physical CPU Count]
		, physical_memory_kb/1024 AS [Physical Memory (MB)], committed_kb/1024 AS [Committed Memory (MB)]
		, committed_target_kb/1024 AS [Committed Target Memory (MB)]
		, max_workers_count AS [Max Workers Count]
		, affinity_type_desc AS [Affinity Type]
		, sqlserver_start_time AS [SQL Server Start Time]
		, virtual_machine_type_desc AS [Virtual Machine Type]  
	FROM sys.dm_os_sys_info WITH (NOLOCK)'

	EXEC SP_EXECUTESQL @sqlcmd
	
END


-- Lock pages in memory enabled
exec ('xp_readerrorlog 0, 1, ''Using locked pages''')