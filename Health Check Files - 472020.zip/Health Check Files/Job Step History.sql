/*============================================================================
  File:     Job Step History.sql

  Summary:  SQL Job history for all jobs filtered by date
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

declare @year char(4)
declare @month varchar(2)
declare @day char(2)
declare @fulltoday varchar(8)

select @year = datepart(yy, getdate())
select @month = datepart(mm, getdate())
select @day = datepart(dd, dateadd(dd, -1, getdate()))
select @fulltoday = @year + @month + @day


SELECT TOP 750 j.name JobName,
h.step_name StepName, 
step_id [StepID],
CONVERT(CHAR(10), CAST(STR(h.run_date,8, 0) AS dateTIME), 111) [RunDate], 
STUFF(STUFF(RIGHT('000000' + CAST ( h.run_time AS VARCHAR(6 ) ) ,6),5,0,':'),3,0,':') RunTime, 
h.run_duration StepDuration,
case h.run_status when 0 then 'failed'
when 1 then 'Succeded' 
when 2 then 'Retry' 
when 3 then 'Cancelled' 
when 4 then 'In Progress' 
end as ExecutionStatus, 
h.message MessageGenerated
FROM msdb..sysjobhistory h 
join msdb..sysjobs j
ON j.job_id = h.job_id
where run_date >= @fulltoday
--and j.name = 'RealPage Restore'
ORDER BY j.name, h.run_date, h.run_time