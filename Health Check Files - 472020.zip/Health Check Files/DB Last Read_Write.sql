/*============================================================================
  File:     DB Last Read_Write

  Summary:  Displays the last date for reads or writes within the DB from the
  					index utilization data.
  
  BOTTOM SCRIPT:  NA
  
  Date:     2015

  Versions: 2005 and above
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.FORTIFIEDDATA.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[ServerName] [nvarchar](128) NULL,
	[DBName] [nvarchar](128) NULL,
	[Last_User_Scan] [datetime] NOT NULL,
	[Last_User_Seek] [datetime] NOT NULL,
	[Last_User_Lookup] [datetime] NOT NULL,
	[Last_User_Update] [datetime] NOT NULL,
	[Run_time] [datetime] NOT NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (1,2,3,4)

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN

	BEGIN

			SET @usecmd = 'USE [' + @DBName + '];'
		
			SET @sqlcmd = '
			INSERT INTO tempdb.dbo.Results
			SELECT [ServerName] = @@SERVERNAME
				, [DBName] = DB_NAME() 
				, [Last_User_Scan] = ISNULL(MAX(Last_User_Scan),''1/1/1900'')
				, [Last_User_Seek] = ISNULL(MAX(Last_User_Seek),''1/1/1900'')
				, [Last_User_Lookup] = ISNULL(MAX(Last_User_Lookup),''1/1/1900'')
				, [Last_User_Update] = ISNULL(MAX(Last_User_Update),''1/1/1900'')
				, GETDATE() Run_time
			FROM sys.indexes AS i (NOLOCK) 
			LEFT JOIN sys.dm_db_index_usage_stats AS s ON i.object_id = s.object_id
					AND i.index_id = s.index_id
			WHERE OBJECTPROPERTY(i.object_id, ''IsUserTable'') = 1'
	END

	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT *
FROM tempdb.dbo.Results
ORDER BY 2, 3
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;