select *
from sys.dm_hadr_cluster