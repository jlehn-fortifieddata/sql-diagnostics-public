/*============================================================================
  File:     CountAllRecordsInTables

  Summary:  Returns record counts and size data for all tables in a DB.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/* Create a temporary table to hold our data, since we're going to iterate through databases */
IF OBJECT_ID('tempdb..#Results') IS NOT NULL
    DROP TABLE #Results;
 
CREATE TABLE [dbo].[#Results](
	[Server Name] [sysname] NOT NULL,
	[DB Name] [sysname] NOT NULL,
	[Schema Name] [sysname] NOT NULL,
	[Table Name] [sysname] NOT NULL,
	[Rowcount] [bigint] NOT NULL,
	[Reserved Space] [bigint] NOT NULL,
	[Data Space] [bigint] NOT NULL,
	[Index Space] [bigint] NOT NULL,
	[Unused Space] [bigint] NOT NULL,
	[Run Time] [datetime] NOT NULL
) ON [PRIMARY]

EXECUTE sys.sp_MSforeachdb
'   USE [?];

	INSERT #Results
	SELECT DISTINCT @@SERVERNAME AS [Server Name] 
		, db_name() AS [DB Name]
		, a3.name AS [Schema Name]
		, a2.name AS [Table Name]
		, a1.rows as [Rowount]
		, (a1.reserved + ISNULL(a4.reserved,0))* 8 AS [Reserved Space]
		, a1.data * 8 AS [Data Space]
		, (CASE WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data ELSE 0 END) * 8 AS [Index Size]
		, (CASE WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used ELSE 0 END) * 8 AS [Unused Space]
		, GETDATE() AS [Run Time]
    FROM
        (SELECT ps.object_id,
            SUM (CASE WHEN (ps.index_id < 2) THEN row_count
                    ELSE 0
                END) AS [rows],
            SUM (ps.reserved_page_count) AS reserved,
            SUM (CASE WHEN (ps.index_id < 2) THEN (ps.in_row_data_page_count + ps.lob_used_page_count + ps.row_overflow_used_page_count)
                    ELSE (ps.lob_used_page_count + ps.row_overflow_used_page_count)
                END) AS data,
            SUM (ps.used_page_count) AS used
        FROM sys.dm_db_partition_stats ps
        GROUP BY ps.object_id) AS a1
    LEFT OUTER JOIN
        (SELECT it.parent_id,
            SUM(ps.reserved_page_count) AS reserved,
            SUM(ps.used_page_count) AS used
         FROM sys.dm_db_partition_stats ps
         INNER JOIN sys.internal_tables it ON (it.object_id = ps.object_id)
         WHERE it.internal_type IN (202,204)
         GROUP BY it.parent_id) AS a4 ON a4.parent_id = a1.object_id
    INNER JOIN sys.all_objects a2  ON a1.object_id = a2.object_id
    INNER JOIN sys.schemas a3 ON a2.schema_id = a3.schema_id
    WHERE a2.type <> N''S'' and a2.type <> N''IT''
'

SELECT *
FROM #Results
WHERE [DB Name] NOT IN ('MASTER', 'MODEL', 'TEMPDB')
ORDER BY 1, 2, 3, 4

DROP TABLE #Results;

/*
DECLARE @ShowResultsInKB1_MB0 BIT
SET @ShowResultsInKB1_MB0 = 0;
WITH tablesizes AS (
    SELECT @@SERVERNAME AS [Server Name] 
		, db_name() AS [DB Name]
        , a3.name AS [schemaname]
        , a2.name AS [tablename]
        , a1.rows as row_count
        , (a1.reserved + ISNULL(a4.reserved,0))* 8 AS reserved
        , a1.data * 8 AS data
        , (CASE WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data ELSE 0 END) * 8 AS index_size
        , (CASE WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used ELSE 0 END) * 8 AS unused
    FROM
        (SELECT
            ps.object_id,
            SUM (
                CASE
                    WHEN (ps.index_id < 2) THEN row_count
                    ELSE 0
                END
                ) AS [rows],
            SUM (ps.reserved_page_count) AS reserved,
            SUM (
                CASE
                    WHEN (ps.index_id < 2) THEN (ps.in_row_data_page_count + ps.lob_used_page_count + ps.row_overflow_used_page_count)
                    ELSE (ps.lob_used_page_count + ps.row_overflow_used_page_count)
                END
                ) AS data,
            SUM (ps.used_page_count) AS used
        FROM sys.dm_db_partition_stats ps
        GROUP BY ps.object_id) AS a1
    LEFT OUTER JOIN
        (SELECT
            it.parent_id,
            SUM(ps.reserved_page_count) AS reserved,
            SUM(ps.used_page_count) AS used
         FROM sys.dm_db_partition_stats ps
         INNER JOIN sys.internal_tables it ON (it.object_id = ps.object_id)
         WHERE it.internal_type IN (202,204)
         GROUP BY it.parent_id) AS a4 ON (a4.parent_id = a1.object_id)
    INNER JOIN sys.all_objects a2  ON ( a1.object_id = a2.object_id )
    INNER JOIN sys.schemas a3 ON (a2.schema_id = a3.schema_id)

-- EXCLUDES SYSTEM AND INTERNAL TABLES
    WHERE a2.type <> N'S' and a2.type <> N'IT'
)

SELECT [Server Name]
	, [DB Name]
	, schemaname
	, tablename
	, row_count
    , CAST(ROUND(CASE @ShowResultsInKB1_MB0 WHEN 1 THEN reserved ELSE reserved / 1024.0 END, 2) AS DECIMAL(18,2))  AS reserved
    , CAST(ROUND(CASE @ShowResultsInKB1_MB0 WHEN 1 THEN data ELSE data / 1024.0 END, 2) AS DECIMAL(18,2))  AS data
    , CAST(ROUND(CASE @ShowResultsInKB1_MB0 WHEN 1 THEN index_size ELSE index_size / 1024.0 END, 2) AS DECIMAL(18,2))  AS index_size
    , CAST(ROUND(CASE @ShowResultsInKB1_MB0 WHEN 1 THEN unused ELSE unused / 1024.0 END, 2) AS DECIMAL(18,2))  AS unused
--	, SUM(usecounts) AS usecounts
FROM tablesizes

--LEFT JOIN (SELECT cacheobjtype, objtype, text, plan_handle, usecounts, refcounts
--FROM sys.dm_exec_cached_plans 
--CROSS APPLY sys.dm_exec_sql_text(plan_handle)) a ON text like '%' + tablename + '%'
--where text like '%search%'
--GROUP BY schemaname, tablename, row_count, reserved, data, index_size, unused
--ORDER BY schemaname, tablename
order by 5 desc
*/

/*
-- STORES OFF GROWTH DATA FOR ALL DATABASES ON THE SERVER
Declare @sql  varchar (max)

Select @sql = ''


Select  @sql = @sql + 'EXEC DBmaint..GetTableSizes ''' + name + '''  ;
'   from  sys.databases 
where name not in ('master' , 'model' , 'msdb' , 'tempdb')
Order by name

-- Print @sql

EXEC (@sql) 

*/