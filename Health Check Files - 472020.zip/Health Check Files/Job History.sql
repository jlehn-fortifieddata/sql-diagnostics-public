/*============================================================================
  File:     Job History.sql

  Summary:  SQL Job history for all jobs filtered by date
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
--============================================================================*/

-- ADD FAILURE CHECK LOGIC AND OTHER ANALYSIS FOR THE JOBS

declare @year char(4)
declare @month varchar(2)
declare @day char(2)
declare @fulltoday varchar(8)

select @year = datepart(yy, getdate())
select @month = datepart(mm, getdate())
select @day = datepart(dd, dateadd(dd, -1, getdate()))
select @fulltoday = @year + @month + @day

select TOP 1000 s1.job_id,
	--upper(originating_server) as 'server', 
	name, 
	step_id,
	run_time,
	cast(substring(cast(run_date as char(8)),1,4) + '-' + substring(cast(run_date as char(8)),5,2)  + '-' + substring(cast(run_date as char(8)),7,2) as smalldatetime) as 'date',
	case when len(run_time) = 6 then substring(cast(run_time as char(6)),1,2) + ':' + substring(cast(run_time as char(6)),3,2) + ':' + substring(cast(run_time as char(6)),5,2)
		when len(run_time) = 5 then '0' + substring(cast(run_time as char(6)),1,1) + ':' + substring(cast(run_time as char(6)),2,2) + ':' + substring(cast(run_time as char(6)),4,2)
		when len(run_time) = 4 then '00:' + substring(cast(run_time as char(6)),1,2) + ':' + substring(cast(run_time as char(6)),3,2)
		when len(run_time) = 3 then '00:0' + substring(cast(run_time as char(6)),1,1) + ':' + substring(cast(run_time as char(6)),2,2)
		when len(run_time) = 2 then '00:00:' + substring(cast(run_time as char(6)),1,2)
		when len(run_time) = 1 then '00:00:0' + substring(cast(run_time as char(6)),1,1) end as 'execution time',
	case when len(run_duration) = 6 then substring(cast(run_duration as char(6)),1,2) + ':' + substring(cast(run_duration as char(6)),3,2) + ':' + substring(cast(run_duration as char(6)),5,2)
		when len(run_duration) = 5 then '0' + substring(cast(run_duration as char(6)),1,1) + ':' + substring(cast(run_duration as char(6)),2,2) + ':' + substring(cast(run_duration as char(6)),4,2)
		when len(run_duration) = 4 then '00:' + substring(cast(run_duration as char(6)),1,2) + ':' + substring(cast(run_duration as char(6)),3,2)
		when len(run_duration) = 3 then '00:0' + substring(cast(run_duration as char(6)),1,1) + ':' + substring(cast(run_duration as char(6)),2,2)
		when len(run_duration) = 2 then '00:00:' + substring(cast(run_duration as char(6)),1,2)
		when len(run_duration) = 1 then '00:00:0' + substring(cast(run_duration as char(6)),1,1) end as 'run_duration',
	case run_status when 0 then 'failed'
		when 1 then 'success'
		when 2 then 'retry (step only)'
		when 3 then 'cancelled'
		when 4 then 'in-progress message'
		when 5 then 'unknown' end as 'job status',
	message--, 
	--run_date
from msdb.dbo.sysjobs as s1
left join msdb.dbo.sysjobhistory as s2 on s2.job_id = s1.job_id
where enabled = 1
--and cast(substring(cast(run_date as char(8)),1,4) + '-' + substring(cast(run_date as char(8)),5,2)  + '-' + substring(cast(run_date as char(8)),7,2) as smalldatetime) = '12/31/2018'
--and run_time >= 150000
--and run_time <= 163000
--and s1.name not like 'lsbackup%'
and run_date >= @fulltoday
