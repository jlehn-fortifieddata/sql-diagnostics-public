/*============================================================================
  File:     DB Mirroring.sql

  Summary:  Lists all the DBs involved in database mirroring.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

IF EXISTS(SELECT CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('PRODUCTVERSION') AS CHAR(1)), 1, 1) IN (9, 1) THEN 1 END)
BEGIN
	SELECT  @@SERVERNAME AS [Server Name]
		, DB_NAME(database_id) 'Database Name'
		, mirroring_state_desc
		, mirroring_role_desc
		, mirroring_safety_level_desc
		, mirroring_partner_instance
	FROM sys.database_mirroring 
	--WHERE database_id = @siDbId
		
END

-- select * from sys.dm_db_mirroring_connections 