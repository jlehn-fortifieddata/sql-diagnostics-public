/*============================================================================
  File:     Deadlock Counts

  Summary:  Shows the deadlock information from perfmon or ringbuffers.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


    SELECT pc.cntr_value as 'Total Deadlocks'
    FROM master.sys.dm_os_performance_counters pc
    WHERE pc.counter_name = 'Number of Deadlocks/sec'
    and pc.instance_name = '_Total'
    and pc.cntr_value >= 1 

--If you're looking for more detail, this DMV can break down the deadlocks a tiny bit more by removing the instance_name filter and adding instance_name to the select clause. That will show a count of deadlocks by object type (key, HoBT, Application, Extent, Page, RID, ...)

--You can also review the xEvents to see that deadlocks have occurred. 

/*
    --Find deadlock info in the ringbuffer
    SELECT CAST(xest.target_data as XML) xml_data, * 
        INTO #ring_buffer_data 
    FROM sys.dm_xe_session_targets xest 
        INNER JOIN sys.dm_xe_sessions xes on xes.[address] = xest.event_session_address 
    WHERE xest.target_name = 'ring_buffer' AND xes.name = 'system_health' 

    DECLARE @xml xml = (select xml_data from #ring_buffer_data)

    SELECT item.value('(./@name)', 'varchar(1000)') as event_name, 
        item.value('(./@timestamp)', 'datetime') as event_time,
        item.query('./data[@name="xml_report"]/value/deadlock') as Deadlock
    FROM @XML.nodes('//event[@name="xml_deadlock_report"]') AS T(item)

*/