/*============================================================================
  File:     Locking - Page Locks

  Summary:  Display operational stats for indexes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[Server Name] [nvarchar](128) NULL,
	[DB Name] [nvarchar](128) NULL,
	[object_nm] [nvarchar](128) NULL,
	[index_id] [int] NOT NULL,
	[partition_number] [int] NOT NULL,
	[page_lock_wait_count] [bigint] NOT NULL,
	[page_lock_wait_in_ms] [bigint] NOT NULL,
	[missing_index_identified] [varchar](1) NOT NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (4)
		AND SD.compatibility_level > 80

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

	SET @usecmd = 'USE [' + @DBName + '];'
	SET @sqlcmd = '
	--The following query demonstrates identifying the top 3 objects associated with waits on page locks:
		INSERT INTO tempdb.dbo.Results
		SELECT TOP 30
			@@SERVERNAME AS [Server Name] 
			, db_name() AS [DB Name]
			, OBJECT_NAME(o.object_id, o.database_id) object_nm
			, o.index_id
			, partition_number
			, page_lock_wait_count
			, page_lock_wait_in_ms
			, case when mid.database_id is null then ''N'' else ''Y'' end as missing_index_identified
		FROM sys.dm_db_index_operational_stats (db_id(), NULL, NULL, NULL) o
		LEFT JOIN (SELECT DISTINCT database_id, object_id
								 FROM sys.dm_db_missing_index_details) as mid
			  ON mid.database_id = o.database_id and mid.object_id = o.object_id
		'

	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT *
FROM tempdb.dbo.Results
ORDER BY 6 DESC
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

/*

SELECT database_id, object_name(object_id), index_id, partition_number, leaf_insert_count, leaf_delete_count, leaf_update_count, leaf_ghost_count, 
nonleaf_insert_count, nonleaf_delete_count, nonleaf_update_count, range_scan_count, forwarded_fetch_count, row_lock_count, 
row_lock_wait_count, page_lock_count, page_lock_wait_count, Index_lock_promotion_attempt_count, index_lock_promotion_count, 
page_compression_attempt_count, page_compression_success_count 
FROM sys.dm_db_index_operational_stats(db_id('018'), NULL, NULL, NULL)
where object_id > 100

*/