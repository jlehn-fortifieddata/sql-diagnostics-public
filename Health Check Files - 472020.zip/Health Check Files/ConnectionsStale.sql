/*============================================================================
  File:     ConnectionsStale.sql

  Summary:  Shows different views of the client connections to the server.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (1, 9) 
BEGIN
-- OLDER CONNECTIONS TO SQL (STALE CONNECTIONS)
	SELECT @@SERVERNAME AS [Server Name]
		,  s1.session_id	
		, host_name
		, client_net_address
		, program_name
		, client_interface_name
		, login_name
		, connect_time
		, last_request_start_time
		, num_reads
		, last_read
		, num_writes
		, last_write
		, cpu_time
		, reads
		, writes
		, logical_reads
		, net_packet_size
		, net_transport
	from sys.dm_exec_connections s1
	join sys.dm_exec_sessions s2 
		on s1.session_id = s2.session_id
	-- STALE CONNECTIONS
	--where last_request_start_time < DATEADD(dd, -2, getdate())
	where connect_time < DATEADD(dd, -2, getdate())
	order by host_name
		, client_net_address
		, login_name
		, num_reads
END
	

ELSE
BEGIN
	SELECT 'Nothing Returned'
END