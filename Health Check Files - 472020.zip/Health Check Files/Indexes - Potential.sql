/*============================================================================
  File:     Indexes - Potential.sql
  
  Summary:  Returns usage data that can be used to determine new and old indexes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Potentially Useful Indexes
SELECT @@SERVERNAME AS [Server Name] 
	, db_name(database_id) [DB Name]
	--, sc.name [Schema Name]
	, OBJECT_NAME(d.object_id, database_id) AS [Table Name]
	, cast(avg_total_user_cost * avg_user_impact * (user_seeks + user_scans) as dec(18,2)) [User Impact]
    , s.user_seeks [Seeks]
	, ISNULL(equality_columns, '''') [Equality]
	, ISNULL(inequality_columns, '''') [Inequality]
	, ISNULL(included_columns, '''') [Included]
    , cast(s.avg_total_user_cost as dec(18,2)) [User Cost]
    , s.avg_user_impact [User Impact]
    , s.unique_compiles [Unique Compiles]
    , s.user_scans [User Scans]
    , s.last_user_seek [Last Seek]
	, 'CREATE INDEX fd_ndx'
		+ OBJECT_NAME(d.object_id, database_id)
		+ '_' + REPLACE(REPLACE(REPLACE(equality_columns, '[', ''), ']', ''), ', ', '_')
		+ ' ON ' 
		--+ db_name(database_id) + '.' 
		--+ sc.name + '.'
		+ OBJECT_NAME(d.object_id, database_id) + '('
		+ equality_columns + ')'
		+ (CASE WHEN included_columns IS NOT NULL THEN 'INCLUDE('
		+ ISNULL(included_columns, '') + ') WITH (DATA_COMPRESSION = row)'
		ELSE ' WITH (DATA_COMPRESSION = row)' END)  [Stmt]
FROM sys.dm_db_missing_index_group_stats s
JOIN sys.dm_db_missing_index_groups g
	ON s.group_handle = g.index_group_handle
JOIN sys.dm_db_missing_index_details d
	ON d.index_handle = g.index_handle
--JOIN sys.objects AS o (NOLOCK) 
--		ON d.object_id = o.object_id
--JOIN sys.schemas AS sc (NOLOCK) 
--	ON o.schema_id = sc.schema_id
--where 
--and object_id('etblCustomerAccounts') = object_id
--ORDER BY s.user_seeks DESC
order by 2, 3
--ORDER BY avg_total_user_cost * avg_user_impact * (user_seeks + user_scans) DESC;

/*
set transaction isolation level read uncommitted 

SELECT
  migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure,
  'CREATE INDEX [missing_index_' + CONVERT (varchar, mig.index_group_handle) + '_' + CONVERT (varchar, mid.index_handle)
  + '_' + LEFT (PARSENAME(mid.statement, 1), 32) + ']'
  + ' ON ' + mid.statement
  + ' (' + ISNULL (mid.equality_columns,'')
    + CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END
    + ISNULL (mid.inequality_columns, '')
  + ')'
  + ISNULL (' INCLUDE (' + mid.included_columns + ')', '') AS create_index_statement,
  migs.*, mid.database_id, mid.[object_id]
FROM sys.dm_db_missing_index_groups mig
	INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
	INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
WHERE migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 10
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC




SELECT @@SERVERNAME AS [Server Name] 
	, db_name(database_id) [DB Name]
	, sc.name [Schema Name]
	, OBJECT_NAME(d.object_id, database_id) AS [Table Name]
	, cast(avg_total_user_cost * avg_user_impact * (user_seeks + user_scans) as dec(18,2)) [User Impact]
    , s.user_seeks [Seeks]
	, ISNULL(equality_columns, '''') [Equality]
	, ISNULL(inequality_columns, '''') [Inequality]
	, ISNULL(included_columns, '''') [Included]
    , cast(s.avg_total_user_cost as dec(18,2)) [User Cost]
    , s.avg_user_impact [User Impact]
	, dpages [Data Pages]
    , s.unique_compiles [Unique Compiles]
    , s.user_scans [User Scans]
    , s.last_user_seek [Last Seek]
	, 'CREATE INDEX idx_'
		+ OBJECT_NAME(d.object_id, database_id)
		+ '_' + REPLACE(REPLACE(REPLACE(equality_columns, '[', ''), ']', ''), ', ', '_')
		+ ' ON ' + db_name(database_id) + '.' 
		+ sc.name + '.'
		+ OBJECT_NAME(d.object_id, database_id) + '('
		+ equality_columns + ')'
		+ (CASE WHEN included_columns IS NOT NULL THEN 'INCLUDE('
		+ ISNULL(included_columns, '') + ') WITH (DATA_COMPRESSION = row)'
		ELSE ' WITH (DATA_COMPRESSION = row)' END)  [Stmt]
FROM sys.dm_db_missing_index_group_stats s
JOIN sys.dm_db_missing_index_groups g
	ON s.group_handle = g.index_group_handle
JOIN sys.dm_db_missing_index_details d
	ON d.index_handle = g.index_handle
JOIN sys.objects AS o (NOLOCK) 
	ON d.object_id = o.object_id
JOIN sys.schemas AS sc (NOLOCK) 
	ON o.schema_id = sc.schema_id
JOIN sysindexes AS i (NOLOCK) 
	ON d.object_id = i.id
	and indid in (0,1)
where db_id() = database_id
--and object_id('etblCustomerAccounts') = object_id
--ORDER BY s.user_seeks DESC
order by 2, 3, 6, 7, 8, 9

SELECT TOP 10 *
FROM sys.dm_db_missing_index_group_stats
ORDER BY avg_total_user_cost * avg_user_impact * (user_seeks + user_scans)DESC;


--- suggested index columns and usage
declare @handle int

select @handle = d.index_handle
from sys.dm_db_missing_index_group_stats s
        ,sys.dm_db_missing_index_groups g
        ,sys.dm_db_missing_index_details d
where s.group_handle = g.index_group_handle
and d.index_handle = g.index_handle

select * 
from sys.dm_db_missing_index_columns(@handle)
order by column_id
*/