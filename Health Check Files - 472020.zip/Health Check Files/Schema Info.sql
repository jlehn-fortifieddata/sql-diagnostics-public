
/*============================================================================
  File:     Schema Info

  Summary:  Displays the schema and other key metadata for each table.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[Server Name] [nvarchar](128) NULL,
	[DB Name] [nvarchar](128) NULL,
	[Schema] [sysname] NULL,
	[Table Name] [sysname] NOT NULL,
	[Column Name] [sysname] NULL,
	[Data Type] [nvarchar](128) NULL,
	[Fill Factor] [tinyint] NULL,
	[Nullable] [varchar](3) NULL,
	[Maximum Length] [int] NULL,
	[Row Count] [bigint] NULL,
	[# of Pages] [int] NULL,
	[Collation Name] [sysname] NULL,
	[HasPK] [int] NULL,
	[UniqueK] [int] NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (4)

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

	SET @usecmd = 'USE [' + @DBName + '];'
	SET @sqlcmd = '
		--LIGHT VERSION
		INSERT INTO tempdb.dbo.Results
		SELECT @@SERVERNAME AS [Server Name] 
			, db_name() AS [DB Name]
			, ist.table_schema [Schema]
			, isc.table_name [Table Name]
			, isc.column_name  [Column Name]
			, isc.data_type [Data Type]
			, si.origfillfactor [Fill Factor]
			, isc.is_nullable [Nullable]
			, ISNULL(COALESCE(isc.character_maximum_length, isc.numeric_precision), 20) AS [Maximum Length]
			, si.rowcnt [Row Count]
			, dpages [# of Pages]
			, ISNULL(collation_name, ''N/A'') [Collation Name]
			, ISNULL(OBJECTPROPERTY(OBJECT_ID(isc.TABLE_NAME), ''TableHasPrimaryKey''), 0) [HasPK]
			, ISNULL(OBJECTPROPERTY(OBJECT_ID(isc.TABLE_NAME), ''TableHasUniqueCnst''), 0) [UniqueK]
		--si.name as IndexName,
		FROM INFORMATION_SCHEMA.COLUMNS isc
		JOIN INFORMATION_SCHEMA.TABLES ist
			ON isc.table_name = ist.table_name
			AND ist.table_schema = isc.table_schema
		JOIN sysindexes si
			ON isc.table_name = OBJECT_NAME(si.id)
		WHERE ist.table_type = ''BASE TABLE''
			AND ist.table_name not like ''DT%''
			AND ist.table_name not like ''#%''
			AND si.indid IN (0,1)
			--and ist.table_name = ''AllergyList''
		ORDER BY ist.table_schema
			, isc.table_name
			, isc.column_name'

	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT TOP 3000 *
FROM tempdb.dbo.Results
ORDER BY 2, 4, 8
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;


/*
DECLARE @table_schema sysname
DECLARE @table sysname
DECLARE @column sysname
DECLARE @datatype sysname
DECLARE @designed_length int
DECLARE @all_count int
DECLARE @sql nvarchar(4000)
DECLARE @origfillfactor varchar(10)

SET NOCOUNT ON 
--EXEC sp_updatestats

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED -- Will speed things up a bit

CREATE TABLE #table_info 
(table_schema sysname NOT NULL
,table_name sysname NOT NULL
,column_name sysname NOT NULL
,data_type sysname NOT NULL
,origfillfactor varchar(10) null
,designed_length int NULL
,max_length int NULL
,distinct_count int NULL
,all_count int NOT NULL
,cardinality AS 
CASE 
WHEN distinct_count IS NULL THEN CAST(data_type AS varchar(7))
WHEN all_count = 0 THEN CAST('No rows' AS varchar(7))
ELSE CAST(
CAST(CAST(distinct_count AS decimal)/CAST(all_count AS decimal) AS decimal(18,4)) AS varchar(7))
END
)

DECLARE c CURSOR FAST_FORWARD FOR 
SELECT 
ist.table_schema,
isc.table_name, 
isc.column_name, 
isc.data_type, 
si.OrigFillFactor,
COALESCE(isc.character_maximum_length, isc.numeric_precision),
si.rowcnt
--si.name as IndexName,
FROM information_schema.columns isc
JOIN information_schema.tables ist
ON isc.table_name = ist.table_name
JOIN sysindexes si
ON isc.table_name = OBJECT_NAME(si.id)
WHERE ist.table_type = 'base table'
AND ist.table_name not like 'dt%'
AND si.indid IN (0,1)
ORDER BY ist.table_schema, isc.table_name, isc.column_name


OPEN c
FETCH NEXT FROM c INTO @table_schema, @table, @column, @datatype, @origfillfactor, @designed_length, @all_count
WHILE @@FETCH_STATUS = 0
BEGIN
IF @datatype IN ('text', 'ntext', 'image', 'xml', 'geography')
BEGIN
SET @sql = 'SELECT ''' + @table_schema + ''', ''' + @table + ''', ''' + @column + ''', ''' + @datatype + ''', ''' + @origfillfactor + ''''
SET @sql = @sql + ', ' + CAST(@designed_length AS varchar(10)) + ', MAX(DATALENGTH([' + @column + ']))'
SET @sql = @sql + ', NULL' + ', ' + CAST(@all_count AS varchar(10)) + ' FROM [' + @table_schema + '].[' + @table + '] WITH (NOLOCK)'
END
ELSE
BEGIN
SET @sql = 'SELECT ''' + @table_schema + ''',''' + @table + ''', ''' + @column + ''', ''' + @datatype + ''', ''' + @origfillfactor + ''''
SET @sql = @sql + ', ' + CAST(@designed_length AS varchar(10)) + ', MAX(LEN(CAST([' + @column + '] AS VARCHAR(8000))))'
SET @sql = @sql + ', COUNT(DISTINCT [' + @column + '])'
SET @sql = @sql + ', ' + CAST(@all_count AS varchar(10)) + ' FROM [' + @table_schema + '].[' + @table + '] WITH (NOLOCK)'
END
PRINT @sql
INSERT INTO #table_info (table_schema, table_name, column_name, data_type, origfillfactor, designed_length, max_length, distinct_count, all_count)
EXEC(@sql)
FETCH NEXT FROM c INTO @table_schema, @table, @column, @datatype, @origfillfactor, @designed_length, @all_count
END
CLOSE c
DEALLOCATE c

--SELECT table_schema, table_name, column_name, data_type, origfillfactor, designed_length, max_length, distinct_count, all_count, cardinality
--FROM #table_info

select	tab.name as TableName, idx.name as IndexName, idx.fill_factor, idx.type_desc, p.data_compression_desc [current_compression],
		col.name as columnname, col.is_computed, idxc.is_included_column, ius.user_seeks, ius.user_scans, ius.user_lookups, 
		ius.user_updates, ius.last_user_seek, ius.last_user_scan, ius.last_user_lookup, ius.last_user_update, ius.last_system_update
INTO #index_info
FROM sys.tables tab 
	JOIN sys.indexes idx on tab.object_id = idx.object_id
	JOIN sys.index_columns idxc ON idxc.index_id = idx.index_id and idxc.object_id = tab.object_id
	JOIN sys.columns col ON col.column_id = idxc.column_id and col.object_id = tab.object_id
	JOIN sys.partitions p ON p.object_id = tab.object_id
		AND p.index_id = idx.index_id
	JOIN sys.dm_db_index_usage_stats ius ON idx.object_id = ius.object_id AND idxc.index_id = ius.index_id

SELECT	distinct a.table_schema, a.table_name, a.column_name, a.data_type, a.origfillfactor, a.designed_length, a.max_length, 
		a.distinct_count, a.all_count, a.cardinality
		--, b.indexName, b.Fill_Factor, b.Type_desc, b.is_computed, b.is_included_column,
		--b.user_seeks, b.user_scans, b.user_lookups, b.user_updates, b.last_user_seek, b.last_user_scan, b.last_user_lookup, b.last_user_update, 
		--b.last_system_update
FROM 
	#table_info a
	 --LEFT JOIN #index_info b ON a.table_name = b.tablename AND a.column_name = b.columnname

SELECT * 
FROM #index_info
ORDER BY 1, 2

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
DROP TABLE #table_info
DROP TABLE #index_info

*/