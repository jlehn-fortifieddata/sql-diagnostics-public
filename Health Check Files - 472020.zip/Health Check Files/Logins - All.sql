/*============================================================================
  File:     All SQL Logins

  Summary:  Shows the logins with sysadmin credentials.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SELECT  @@SERVERNAME AS [Server Name],
		p.name AS [loginname] ,
        p.type ,
        p.type_desc ,
        p.is_disabled,
        CONVERT(VARCHAR(10),p.create_date ,101) AS [created],
        CONVERT(VARCHAR(10),p.modify_date , 101) AS [update],
		denylogin,
		hasaccess,
		isntname,
		isntgroup,
		sysadmin,
		securityadmin,
		serveradmin,
		setupadmin,
		processadmin,
		diskadmin,
		dbcreator,
		bulkadmin
FROM    sys.server_principals p
        JOIN sys.syslogins s ON p.sid = s.sid
WHERE   p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')
        -- Logins that are not process logins
        AND p.name NOT LIKE '##%'
        -- Logins that are sysadmins
        --AND s.sysadmin = 1
GO