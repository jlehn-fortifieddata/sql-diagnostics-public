/*============================================================================
  File:    Numa Nodes

  Summary:  Displays the # of NUMA nodes.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SELECT DISTINCT 
	@@SERVERNAME 'Server Name'
	, memory_node_id
FROM sys.dm_os_memory_clerks

