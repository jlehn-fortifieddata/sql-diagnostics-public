
Select count(1) as 'SSIS Executions' 
from msdb..sysssislog;
