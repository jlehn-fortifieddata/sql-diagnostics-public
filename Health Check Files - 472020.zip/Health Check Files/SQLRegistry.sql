
-- SQL Server Registry information (SQL Server 2008 R2 SP1 or greater)  (Query 12)
SELECT registry_key, value_name, value_data
FROM sys.dm_server_registry WITH (NOLOCK) OPTION (RECOMPILE);

-- This lets you safely read some SQL Server related 
-- information from the Windows Registry
