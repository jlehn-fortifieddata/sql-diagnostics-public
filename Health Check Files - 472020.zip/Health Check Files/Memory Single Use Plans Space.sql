
-- Find single-use, ad-hoc queries that are bloating the plan cache  (Query 34)
SELECT TOP(250) [ServerName] = @@SERVERNAME
				, [DBName] = DB_NAME() 
				, CAST([text] AS VARCHAR(500)) AS [QueryText]
				, cp.size_in_bytes/1024 [SizeInKBs]
FROM sys.dm_exec_cached_plans AS cp WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) 
WHERE cp.cacheobjtype = N'Compiled Plan' 
AND cp.objtype = N'Adhoc' 
AND cp.usecounts = 1
ORDER BY cp.size_in_bytes DESC OPTION (RECOMPILE);
