
Select count(1) as 'SSRS Executions' 
from ReportServer..ExecutionLog2;
