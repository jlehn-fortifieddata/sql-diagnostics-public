SELECT
	AG.name AS [AvailabilityGroupName],
	ISNULL(agstates.primary_replica, '') AS [PrimaryReplicaServerName],
	ISNULL(arstates.role, 3) AS [LocalReplicaRole],
	dbcs.database_name AS [DatabaseName],
	ISNULL(dbrs.synchronization_state, 0) AS [SynchronizationState],
	ISNULL(dbrs.is_suspended, 0) AS [IsSuspended],
	ISNULL(dbcs.is_database_joined, 0) AS [IsJoined]
FROM master.sys.availability_groups AS AG
LEFT JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
LEFT JOIN master.sys.dm_hadr_database_replica_states AS dbrs
   ON dbcs.replica_id = dbrs.replica_id 
   AND dbcs.group_database_id = dbrs.group_database_id
ORDER BY AG.name ASC, dbcs.database_name


/*
-- RUN ON THE PRIMARY NODE TO SUSPEND THE AG

SELECT 'ALTER DATABASE [' + 
	dbcs.database_name 
	+ '] SET HADR SUSPEND'
FROM master.sys.availability_groups AS AG
LEFT JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
LEFT JOIN master.sys.dm_hadr_database_replica_states AS dbrs
   ON dbcs.replica_id = dbrs.replica_id 
   AND dbcs.group_database_id = dbrs.group_database_id
ORDER BY AG.name ASC, dbcs.database_name


-- RUN ON THE OTHER NODE TO RESUME THE AG AFTER A FORCED FAILOVER

SELECT 'ALTER DATABASE [' + 
	dbcs.database_name 
	+ '] SET HADR RESUME'
FROM master.sys.availability_groups AS AG
LEFT JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
LEFT JOIN master.sys.dm_hadr_database_replica_states AS dbrs
   ON dbcs.replica_id = dbrs.replica_id 
   AND dbcs.group_database_id = dbrs.group_database_id
ORDER BY AG.name ASC, dbcs.database_name

-- SYNC AND UNSYNC COMMIT - RUN ON PRIMARY
ALTER AVAILABILITY GROUP SQL01DAG MODIFY REPLICA ON 'SQL2'
   WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT);

   
--- YOU MUST EXECUTE THE FOLLOWING SCRIPT IN SQLCMD MODE.

:Connect SQL2

ALTER AVAILABILITY GROUP [SQL01DAG] FORCE_FAILOVER_ALLOW_DATA_LOSS;

GO



   
*/