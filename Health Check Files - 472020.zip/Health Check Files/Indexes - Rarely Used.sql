/*============================================================================
  File:     Index - Rarely Used Indexes

  Summary:  Sample stored procedure that lists rarely-used indexes. Because the number and type of accesses are 
		tracked in dmvs, this procedure can find indexes that are rarely useful. Because the cost of these indexes 
		is incurred during maintenance (e.g. insert, update, and delete operations), the write costs of rarely-used 
		indexes may outweigh the benefits.

  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/* Create a temporary table to hold our data, since we're going to iterate through databases */

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[ServerName] [nvarchar](128) NULL,
	[DBName] [nvarchar](128) NULL,
	[Schema] [sysname] NOT NULL,
	[TableName] [nvarchar](128) NULL,
	[IndexName] [nvarchar](128) NULL,
	[ColumnNames] [nvarchar](max) NULL,
	[IndexID] [int] NOT NULL,
	[TotalPages] [bigint] NOT NULL,
	[TotalSize_GB] [numeric](13, 4) NOT NULL,
	[InRowSize_GB] [numeric](13, 4) NOT NULL,
	[UserSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[TotalUsage] [bigint] NULL,
	[%Read] [decimal](5, 2) NULL,
	[%Write] [decimal](5, 2) NULL,
	[Compressed] [nvarchar](60) NULL,
	[Filegroup Name] [sysname] NOT NULL,
	[IsUnique] [bit] NULL,
	[FillFactor] [tinyint] NOT NULL,
	[Count] [int] NULL,
	[Disabled] [bit] NULL,
	[Partition#] [int] NOT NULL,
	[RowLocks] [bit] NULL,
	[PageLocks] [bit] NULL,
	[Hypothetical] [bit] NULL,
	[IsDefault] [bit] NOT NULL,
	[IsReadOnly] [bit] NOT NULL,
	[Last_User_Scan] [datetime] NULL,
	[Last_User_Seek] [datetime] NULL,
	[Run_time] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (4)

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

	IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (8, 9) 
	BEGIN
		SET @usecmd = 'USE [' + @DBName + '];'
		SET @sqlcmd = '
		INSERT INTO tempdb.dbo.Results
		SELECT [ServerName] = @@SERVERNAME
				, [DBName] = DB_NAME() 
				, [Schema]  = sc.name
				, TableName = OBJECT_NAME(i.object_id)
				, IndexName =  (CASE i.index_id WHEN 0 THEN ''(HEAP)'' ELSE i.name END)
				, ColumnNames = (CASE i.index_id WHEN 0 THEN ''(HEAP)'' ELSE SUBSTRING(c.indexColumns, 1, LEN(c.indexColumns) - 1) END)
				, [IndexID] = i.Index_ID
				, TotalPages = ISNULL(SUM(sa.total_pages), 0)
				, TotalSize_GB = ISNULL(CAST(SUM(sa.total_pages)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, InRowSize_GB = ISNULL(CAST(SUM(CASE sa.[type] WHEN 1 THEN sa.total_pages
					ELSE 0 END)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, [UserSeeks] = ISNULL(SUM(User_Seeks), 0) 
				, [UserScans] = ISNULL(SUM(User_Scans), 0) 
				, [UserLookups] = ISNULL(SUM(User_Lookups), 0) 
				, [UserUpdates] = ISNULL(SUM(User_Updates), 0) 
				, [TotalUsage] = ISNULL(SUM(User_seeks + user_scans + user_lookups + user_updates), 0) 
				, [%Read] = ISNULL(CAST(CAST(SUM(User_seeks + user_scans + user_lookups) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, [%Write] = ISNULL(CAST(CAST(SUM(user_updates) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, [Compression] = ''NONE''
				, [Filegroup Name] = f.name
				, [IsUnique] = Is_Unique
				, [FillFactor] = i.Fill_Factor
				, (SELECT count(*)
					FROM sys.indexes r 
					WHERE r.object_id = i.object_id
					AND Is_Disabled = 0) ''Count''
				, [Disabled] = Is_Disabled
				, [Partition#] = ISNULL(Partition_Number, 0)
				, [RowLocks] = Allow_Row_Locks
				, [PageLocks] = Allow_Page_Locks
				, [Hypothetical] = Is_Hypothetical
				, [IsDefault] = f.is_default
				, [IsReadOnly] = f.is_read_only
				, [Last_User_Scan] = ISNULL(MAX(Last_User_Scan),''1/1/1900'')
				, [Last_User_Seek] = ISNULL(MAX(Last_User_Seek),''1/1/1900'')
				, GETDATE() Run_time
			FROM sys.indexes AS i (NOLOCK) 
			LEFT JOIN sys.dm_db_index_usage_stats AS s ON i.object_id = s.object_id
				AND i.index_id = s.index_id and s.database_id = DB_ID() --cmm added database_id restriction
			JOIN sys.objects AS o (NOLOCK) 
				ON i.object_id = o.object_id
				and o.type in (''U'',''V'')
			JOIN sys.schemas AS sc (NOLOCK) 
				ON o.schema_id = sc.schema_id
			JOIN sys.filegroups f 
				ON i.data_space_id = f.data_space_id
			LEFT JOIN sys.partitions AS sp (NOLOCK) 
				ON i.object_id = sp.object_id
					AND i.index_id = sp.index_id
			LEFT JOIN sys.allocation_units AS sa (NOLOCK) 
				ON sa.container_id = sp.hobt_id
			LEFT JOIN (select distinct
				object_id
				, index_id
				, indexColumns = (SELECT COL_NAME(object_id,column_id )
							+ CASE is_included_column WHEN 1 THEN '' (INCL), '' ELSE '','' END AS ''data()''
						FROM sys.index_columns t2 (NOLOCK)
						WHERE t1.object_id =t2.object_id
						AND t1.index_id = t2.index_id
							FOR XML PATH (''''))
						FROM sys.index_columns t1  ) c ON
						c.index_id = i.index_id
						and c.object_id = i.object_id
			WHERE OBJECTPROPERTY(i.object_id, ''IsUserTable'') = 1
				--AND ''events'' = object_name(i.object_id)
				--AND i.name like ''idx_%'' 
			GROUP BY i.object_id
				, i.Name
				, sc.Name
				, i.Index_ID
				, Partition_Number
				, c.indexColumns
				, Is_Unique
				, i.Fill_Factor
				, Is_Disabled
				, Allow_Row_Locks
				, Allow_Page_Locks
				, Is_Hypothetical
				, f.name
				, f.is_default
				, f.is_read_only
		ORDER BY 
			[UserSeeks]
			, [UserScans] 
			, [UserLookups]
			, [TotalUsage] DESC'

	END
	
	IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) = '1'
	BEGIN
		SET @usecmd = 'USE [' + @DBName + '];'
		SET @sqlcmd = '
		INSERT INTO tempdb.dbo.Results
		SELECT [ServerName] = @@SERVERNAME
				, [DBName] = DB_NAME() 
				, [Schema]  = sc.name
				, TableName = OBJECT_NAME(i.object_id)
				, IndexName =  (CASE i.index_id WHEN 0 THEN ''(HEAP)'' ELSE i.name END)
				, ColumnNames = (CASE i.index_id WHEN 0 THEN ''(HEAP)'' ELSE SUBSTRING(c.indexColumns, 1, LEN(c.indexColumns) - 1) END)
				, [IndexID] = i.Index_ID
				, TotalPages = ISNULL(SUM(sa.total_pages), 0)
				, TotalSize_GB = ISNULL(CAST(SUM(sa.total_pages)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, InRowSize_GB = ISNULL(CAST(SUM(CASE sa.[type] WHEN 1 THEN sa.total_pages
					ELSE 0 END)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, [UserSeeks] = ISNULL(SUM(User_Seeks), 0) 
				, [UserScans] = ISNULL(SUM(User_Scans), 0) 
				, [UserLookups] = ISNULL(SUM(User_Lookups), 0) 
				, [UserUpdates] = ISNULL(SUM(User_Updates), 0) 
				, [TotalUsage] = ISNULL(SUM(User_seeks + user_scans + user_lookups + user_updates), 0) 
				, [%Read] = ISNULL(CAST(CAST(SUM(User_seeks + user_scans + user_lookups) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, [%Write] = ISNULL(CAST(CAST(SUM(user_updates) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, Compressed = (CASE WHEN Data_Compression_Desc IS NULL THEN ''NONE'' 
					ELSE Data_Compression_Desc END)
				, [Filegroup Name] = f.name
				, [IsUnique] = Is_Unique
				, [FillFactor] = i.Fill_Factor
				, (SELECT count(*)
					FROM sys.indexes r 
					WHERE r.object_id = i.object_id) ''Count''
				, [Disabled] = Is_Disabled
				, [Partition#] = ISNULL(Partition_Number, 0)
				, [RowLocks] = Allow_Row_Locks
				, [PageLocks] = Allow_Page_Locks
				, [Hypothetical] = Is_Hypothetical
				, [IsDefault] = f.is_default
				, [IsReadOnly] = f.is_read_only
				, [Last_User_Scan] = ISNULL(MAX(Last_User_Scan),''1/1/1900'')
				, [Last_User_Seek] = ISNULL(MAX(Last_User_Seek),''1/1/1900'')
				, GETDATE() Run_time
			FROM sys.indexes AS i (NOLOCK) 
			LEFT JOIN sys.dm_db_index_usage_stats AS s ON i.object_id = s.object_id
				AND i.index_id = s.index_id and s.database_id = DB_ID() --cmm added database_id restriction
			JOIN sys.objects AS o (NOLOCK) 
				ON i.object_id = o.object_id
				and o.type in (''U'',''V'')
			JOIN sys.schemas AS sc (NOLOCK) 
				ON o.schema_id = sc.schema_id
			JOIN sys.filegroups f 
				ON i.data_space_id = f.data_space_id
			LEFT JOIN sys.partitions AS sp (NOLOCK) 
				ON i.object_id = sp.object_id
					AND i.index_id = sp.index_id
			LEFT JOIN sys.allocation_units AS sa (NOLOCK) 
				ON sa.container_id = sp.hobt_id
			LEFT JOIN (select distinct
				object_id
				, index_id
				, indexColumns = (SELECT COL_NAME(object_id,column_id )
							+ CASE is_included_column WHEN 1 THEN '' (INCL), '' ELSE '','' END AS ''data()''
						FROM sys.index_columns t2 (NOLOCK)
						WHERE t1.object_id =t2.object_id
						AND t1.index_id = t2.index_id
							FOR XML PATH (''''))
						FROM sys.index_columns t1  ) c ON
						c.index_id = i.index_id
						and c.object_id = i.object_id
			WHERE OBJECTPROPERTY(i.object_id, ''IsUserTable'') = 1
				--AND ''events'' = object_name(i.object_id)
				--AND i.name like ''idx_%'' 
			GROUP BY i.object_id
				, i.Name
				, sc.Name
				, Data_Compression_Desc
				, i.Index_ID
				, Partition_Number
				, c.indexColumns
				, Is_Unique
				, i.Fill_Factor
				, Is_Disabled
				, Allow_Row_Locks
				, Allow_Page_Locks
				, Is_Hypothetical
				, f.name
				, f.is_default
				, f.is_read_only
		ORDER BY 
			[UserSeeks]
			, [UserScans] 
			, [UserLookups]
			, [TotalUsage] DESC'
	
	END
	
	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT *
FROM tempdb.dbo.Results
ORDER BY 2, 4
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

/*
		SELECT [ServerName] = @@SERVERNAME
				, [DBName] = DB_NAME() 
				, [Schema]  = sc.name
				, TableName = OBJECT_NAME(i.object_id)
				, IndexName =  (CASE i.index_id WHEN 0 THEN '(HEAP)' ELSE i.name END)
				, ColumnNames = (CASE i.index_id WHEN 0 THEN '(HEAP)' ELSE SUBSTRING(c.indexColumns, 1, LEN(c.indexColumns) - 1) END)
				, [IndexID] = i.Index_ID
				, TotalPages = ISNULL(SUM(sa.total_pages), 0)
				, TotalSize_GB = ISNULL(CAST(SUM(sa.total_pages)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, InRowSize_GB = ISNULL(CAST(SUM(CASE sa.[type] WHEN 1 THEN sa.total_pages
					ELSE 0 END)*8./1024./1024. AS NUMERIC(13,4)), 0)
				, [UserSeeks] = ISNULL(SUM(User_Seeks), 0) 
				, [UserScans] = ISNULL(SUM(User_Scans), 0) 
				, [UserLookups] = ISNULL(SUM(User_Lookups), 0) 
				, [UserUpdates] = ISNULL(SUM(User_Updates), 0) 
				, [TotalUsage] = ISNULL(SUM(User_seeks + user_scans + user_lookups + user_updates), 0) 
				, [%Read] = ISNULL(CAST(CAST(SUM(User_seeks + user_scans + user_lookups) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, [%Write] = ISNULL(CAST(CAST(SUM(user_updates) AS DEC(16,2))/CAST(REPLACE((SUM(User_seeks + user_scans + user_lookups + user_updates)), 0, 1) AS DEC(16,2)) * 100 AS DEC(5,2)) ,0)
				, Compressed = (CASE WHEN Data_Compression_Desc IS NULL THEN 'NONE' 
					ELSE Data_Compression_Desc END)
				, [Filegroup Name] = f.name
				, [IsUnique] = Is_Unique
				, [FillFactor] = i.Fill_Factor
				, (SELECT count(*)
					FROM sys.indexes r 
					WHERE r.object_id = i.object_id) 'Count'
				, [Disabled] = Is_Disabled
				, [Partition#] = ISNULL(Partition_Number, 0)
				, [RowLocks] = Allow_Row_Locks
				, [PageLocks] = Allow_Page_Locks
				, [Hypothetical] = Is_Hypothetical
				, [IsDefault] = f.is_default
				, [IsReadOnly] = f.is_read_only
				, [Last_User_Scan] = ISNULL(MAX(Last_User_Scan),'1/1/1900')
				, [Last_User_Seek] = ISNULL(MAX(Last_User_Seek),'1/1/1900')
				, GETDATE() Run_time
			FROM sys.indexes AS i (NOLOCK) 
			LEFT JOIN sys.dm_db_index_usage_stats AS s ON i.object_id = s.object_id
				AND i.index_id = s.index_id
			JOIN sys.objects AS o (NOLOCK) 
				ON i.object_id = o.object_id
				and o.type in ('U','V')
			JOIN sys.schemas AS sc (NOLOCK) 
				ON o.schema_id = sc.schema_id
			JOIN sys.filegroups f 
				ON i.data_space_id = f.data_space_id
			LEFT JOIN sys.partitions AS sp (NOLOCK) 
				ON i.object_id = sp.object_id
					AND i.index_id = sp.index_id
			LEFT JOIN sys.allocation_units AS sa (NOLOCK) 
				ON sa.container_id = sp.hobt_id
			LEFT JOIN (select distinct
				object_id
				, index_id
				, indexColumns = (SELECT COL_NAME(object_id,column_id )
							+ CASE is_included_column WHEN 1 THEN ' (INCL), ' ELSE ',' END AS 'data()'
						FROM sys.index_columns t2 (NOLOCK)
						WHERE t1.object_id =t2.object_id
						AND t1.index_id = t2.index_id
							FOR XML PATH (''))
						FROM sys.index_columns t1  ) c ON
						c.index_id = i.index_id
						and c.object_id = i.object_id
			WHERE OBJECTPROPERTY(i.object_id, 'IsUserTable') = 1
				--AND 'events' = object_name(i.object_id)
			GROUP BY i.object_id
				, i.Name
				, sc.Name
				, Data_Compression_Desc
				, i.Index_ID
				, Partition_Number
				, c.indexColumns
				, Is_Unique
				, i.Fill_Factor
				, Is_Disabled
				, Allow_Row_Locks
				, Allow_Page_Locks
				, Is_Hypothetical
				, f.name
				, f.is_default
				, f.is_read_only
		ORDER BY 
			[UserSeeks]
			, [UserScans] 
			, [UserLookups]
			, [TotalUsage] DESC
*/
/*
SELECT [ServerName] = @@SERVERNAME
		, [DBName] = DB_NAME() 
		--, [Schema]  = sc.name
		--, TableName = OBJECT_NAME(i.object_id)
		--, IndexName =  (CASE i.index_id WHEN 0 THEN '(HEAP)' ELSE i.name END)
		, [Last_User_Scan] = ISNULL(MAX(Last_User_Scan),'1/1/1900')
		, [Last_User_Seek] = ISNULL(MAX(Last_User_Seek),'1/1/1900')
		, GETDATE() Run_time
	FROM sys.indexes AS i (NOLOCK) 
	LEFT JOIN sys.dm_db_index_usage_stats AS s ON i.object_id = s.object_id
		AND i.index_id = s.index_id
	JOIN sys.objects AS o (NOLOCK) 
		ON i.object_id = o.object_id
		and o.type in ('U','V')
	JOIN sys.schemas AS sc (NOLOCK) 
		ON o.schema_id = sc.schema_id
	JOIN sys.filegroups f 
		ON i.data_space_id = f.data_space_id
	LEFT JOIN sys.partitions AS sp (NOLOCK) 
		ON i.object_id = sp.object_id
			AND i.index_id = sp.index_id
	LEFT JOIN sys.allocation_units AS sa (NOLOCK) 
		ON sa.container_id = sp.hobt_id
	LEFT JOIN (select distinct
		object_id
		, index_id
		, indexColumns = (SELECT COL_NAME(object_id,column_id )
					+ CASE is_included_column WHEN 1 THEN ' (INCL), ' ELSE ',' END AS 'data()'
				FROM sys.index_columns t2 (NOLOCK)
				WHERE t1.object_id =t2.object_id
				AND t1.index_id = t2.index_id
					FOR XML PATH (''))
				FROM sys.index_columns t1  ) c ON
				c.index_id = i.index_id
				and c.object_id = i.object_id
	WHERE OBJECTPROPERTY(i.object_id, 'IsUserTable') = 1
		--AND 'events' = object_name(i.object_id)
	--GROUP BY i.object_id
	--	, i.Name
	--	, sc.Name
	--	, i.index_id

*/
