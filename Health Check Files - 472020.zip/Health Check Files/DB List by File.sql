/*============================================================================
  File:     DB List by File.sql

  Summary:  Lists all the DBs details and bottom code shows the size and free space
  
  Date:     2008

  Versions: 2005 and greater
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.FORTIFIEDDATA.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SET NOCOUNT ON

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (7, 8) 
BEGIN
	exec sp_helpdb
END

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (9, 1) 
BEGIN
	DECLARE @Granularity varchar(10)
	, @Database_Name sysname 
	, @SQL varchar(5000)   
	
	set @Granularity = 'Database'
	
	
	IF EXISTS (SELECT NAME FROM tempdb..sysobjects WHERE NAME = '##Results')   
	   BEGIN   
	       DROP TABLE ##Results   
	   END  
	     
	CREATE TABLE ##Results ([Database Name] sysname
		, [File Name] sysname
		, [File Group] NVARCHAR(260)
		, [Physical Name] NVARCHAR(260)
		, [File Type] VARCHAR(4)
		, [Total Size in MB] INT
		, [Available Space in MB] INT
		, [Growth Units] VARCHAR(15)
		, [Max File Size in MB] INT)  
	
	SELECT @SQL =   
	'USE [?] 
	INSERT INTO ##Results([Database Name]
		, [File Name]
		, [File Group]
		, [Physical Name]
		, [File Type]
		, [Total Size in MB]
		, [Available Space in MB]
		, [Growth Units]
		, [Max File Size in MB])   
	SELECT DB_NAME(),  
		s1.[name] AS [File Name],   
		s2.[name] AS [File Group],  
		physical_name AS [Physical Name],   
		[File Type] =   
		CASE s1.type  
		WHEN 0 THEN ''Data'''   
		+  
				   'WHEN 1 THEN ''Log'''  
		+  
			   'END,  
		[Total Size in MB] =  
			CASE ceiling([size]/128)   
			WHEN 0 THEN 1  
			ELSE ceiling([size]/128)  
		END,  
		[Available Space in MB] =   
		CASE ceiling([size]/128)  
		WHEN 0 THEN (1 - CAST(FILEPROPERTY(s1.[name], ''SpaceUsed''' + ') as int) /128)  
		ELSE (([size]/128) - CAST(FILEPROPERTY(s1.[name], ''SpaceUsed''' + ') as int) /128)  
		END,  
		[Growth Units]  =   
		CASE [is_percent_growth]   
		WHEN 1 THEN CAST(growth AS varchar(20)) + ''%'''  
		+  
				   'ELSE CAST(growth*8/1024 AS varchar(20)) + ''MB'''  
		+  
			   'END,  
		[Max File Size in MB] =   
		CASE [max_size]  
		WHEN -1 THEN NULL  
		WHEN 268435456 THEN NULL  
		ELSE [max_size]  
		END  
	FROM sys.database_files s1
	LEFT JOIN sys.filegroups s2 ON s1.data_space_id = s2.data_space_id
	ORDER BY [File Type], [file_id]'  
	
	--Print the command to be issued against all databases  
	PRINT @SQL  
	
	--Run the command against each database  
	EXEC sp_MSforeachdb @SQL  

	SELECT @@SERVERNAME AS [Server Name]
		, [Database Name]
		, [File Name]
		, [File Group]
		, [Physical Name]
		, [File Type] 
		, [Total Size in MB] AS [DB Size (MB)]
		, [Available Space in MB] AS [DB Free (MB)] 
		, CEILING(CAST([Available Space in MB] AS decimal(10,1)) / [Total Size in MB]*100) AS [Free Space %]  
		, [Growth Units]  
		, [Max File Size in MB] AS [Grow Max Size (MB)]   
	FROM ##Results   	

END

IF EXISTS (SELECT NAME FROM tempdb..sysobjects WHERE NAME = '##Results')   
   BEGIN   
       DROP TABLE ##Results   
   END  