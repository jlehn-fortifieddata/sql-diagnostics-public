select *
from sys.dm_hadr_cluster_networks