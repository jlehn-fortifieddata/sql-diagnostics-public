/*============================================================================
  File:     Connections Info

  Summary:  Shows different views of the client connections to the server.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (1, 9) 
BEGIN
	-- TOTAL CONNECTIONS BY HOST
	SELECT @@SERVERNAME AS [Server Name]
		, HOST_NAME
		,client_net_address
		, login_name
		, program_name
		, SUM(num_reads) AS [Total Reads]
		, SUM(num_writes) AS [Total Writes]
		, COUNT(*) AS [Total Connections]
		, GETDATE() AS [Run Time]
	FROM sys.dm_exec_connections s1
	JOIN sys.dm_exec_sessions s2 
		on s1.session_id = s2.session_id
	group by host_name
		,client_net_address
		, login_name
		, program_name
	order by HOST_NAME desc
END

ELSE
BEGIN
	SELECT 'Nothing Returned'
END