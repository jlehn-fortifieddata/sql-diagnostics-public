/*============================================================================
  File:     Historical Blocking Info from DMV.sql

  Summary:  Historical blocking data by index.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.FORTIFIEDDB.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[Server Name] [nvarchar](128) NULL,
	[DB Name] [nvarchar](128) NULL,
	[Obj] [nvarchar](128) NULL,
	[row_lock_count] [bigint] NOT NULL,
	[page_lock_count] [bigint] NOT NULL,
	[No_Of_Locks] [bigint] NULL,
	[row_lock_wait_count] [bigint] NOT NULL,
	[page_lock_wait_count] [bigint] NOT NULL,
	[No_Of_Blocks] [bigint] NULL,
	[row_lock_wait_in_ms] [bigint] NOT NULL,
	[page_lock_wait_in_ms] [bigint] NOT NULL,
	[Block_Wait_Time] [bigint] NULL,
	[index_lock_promotion_count] [bigint] NULL,
	[index_id] [int] NOT NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (4)

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

		SET @usecmd = 'USE [' + @DBName + '];'
		SET @sqlcmd = '

		INSERT INTO tempdb.dbo.Results
		SELECT TOP 100
			@@SERVERNAME AS [Server Name] 
			, db_name() AS [DB Name]
			, object_name(object_id) Obj
			, row_lock_count
			, page_lock_count
			, row_lock_count + page_lock_count No_Of_Locks
			, row_lock_wait_count
			, page_lock_wait_count
			, row_lock_wait_count + page_lock_wait_count No_Of_Blocks
			, row_lock_wait_in_ms
			, page_lock_wait_in_ms
			, row_lock_wait_in_ms + page_lock_wait_in_ms Block_Wait_Time
			, index_lock_promotion_count
			, index_id
		from sys.dm_db_index_operational_stats(NULL,NULL,NULL,NULL)
		-- Filter by the DB or run at the server level but will not resolve objects.!!!!
		where DB_ID() = database_id
		AND (row_lock_count + page_lock_count) > 0
		order by Block_Wait_Time desc
		--order by No_Of_Blocks desc
		'
	
	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT TOP 100 *
FROM tempdb.dbo.Results
WHERE No_Of_Blocks > 0
ORDER BY 9 DESC
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;
