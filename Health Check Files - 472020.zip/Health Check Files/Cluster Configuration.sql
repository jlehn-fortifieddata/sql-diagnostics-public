/*============================================================================
  File:     Admin - Server Audit Report

  Summary:  Displays information about the cluster.
  
  Date:     2008

  Versions: !!!!!!!!!!2005, 2008 is on the bottom.!!!!!!!!!!!!!!
			Requires KT's 2005 and 2008 modified index scripts.
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Get information about your OS cluster (if your database server is in a cluster)  (Query 11)
SELECT VerboseLogging, SqlDumperDumpFlags, SqlDumperDumpPath, 
       SqlDumperDumpTimeOut, FailureConditionLevel, HealthCheckTimeout
FROM sys.dm_os_cluster_properties WITH (NOLOCK) OPTION (RECOMPILE);

-- You will see no results if your instance is not clustered


-- Get information about your cluster nodes and their status  (Query 12) 
-- (if your database server is in a cluster)
SELECT NodeName, status_description, is_current_owner
FROM sys.dm_os_cluster_nodes WITH (NOLOCK) OPTION (RECOMPILE);


--Find name of the Node on which SQL Server Instance is Currently running
--If the server is not cluster, then the above query returns the Host Name of the Server.
SELECT SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS [CurrentNodeName] 

--Find SQL Server Cluster Nodes
--Using Function
SELECT * FROM fn_virtualservernodes() 

--Find SQL Server Cluster Shared Drives
--Using Function
SELECT * FROM fn_servershareddrives() 

--Using DMV
SELECT * FROM sys.dm_io_cluster_shared_drives

