/*
	Jobs
*/

select j.name as JobName, j.enabled as JobEnabled, j.description as JobDescription, j.start_step_id as JobStartStep 
	,js.step_id as JobStepID, js.step_name as JobStepName, js.subsystem as JobStepSubsystem, js.database_name as JobStepDatabase, js.command as JobStepCommand
	,case sch.freq_type
			when 1 then 'One Time Only'
			when 4 then 'Daily'
			when 8 then 'Weekly'				
			when 16 then 'Monthly'
			when 32 then 'Relative Monthly'
			else 'NULL'
		end ScheduledFrequency
			,case sch.freq_type
			when 1 then 'One Time Only'
			when 4 then 'Every '+ cast(sch.freq_interval as varchar)+' day(s)'
			when 8 then 
				case when freq_interval & 1 = 1 then 'Sunday ' else '' end +
				case when freq_interval & 2 = 2 then 'Monday ' else '' end +
				case when freq_interval & 4 = 4 then 'Tuesday ' else '' end +
				case when freq_interval & 8 = 8 then 'Wednesday ' else '' end +
				case when freq_interval & 16 = 16 then 'Thursday ' else '' end +
				case when freq_interval & 32 = 32 then 'Friday ' else '' end +
				case when freq_interval & 64 = 64 then 'Saturday '   else '' end 				
			when 16 then 'On the '+ cast(sch.freq_interval as varchar)+' day of the month'
			when 32 then
				case sch.freq_relative_interval
					when 1 then 'First '
					when 2 then 'Second '
					when 4 then 'Third '
					when 8 then 'Fourth '
					when 16 then 'Last '
				end + 
				case sch.freq_interval
						when 1 then 'Sunday'
						when 2 then 'Monday'
						when 3 then 'Tuesday'
						when 4 then 'Wednesday'
						when 5 then 'Thursday'
						when 6 then 'Friday'
						when 7 then 'Saturday' 
						when 8 then 'Day'
						when 9 then 'Weekday'
						when 10 then 'Weekend day'
				end 				
			else 'NULL'
		end ScheduledDays
		,case sch.freq_subday_type
			when 1 then 'At '+ CAST(sch.active_start_time / 10000 AS VARCHAR(10))+ ':' + RIGHT('00' + CAST(sch.active_start_time % 10000 / 100 AS VARCHAR(10)), 2)
			when 2 then 'Every '+ cast(sch.freq_subday_interval as varchar)  +' Seconds'
			when 4 then 'Every '+ cast(sch.freq_subday_interval as varchar)  +' Minutes'
			when 8 then 'Every '+ cast(sch.freq_subday_interval as varchar)  +' Hours'
			else 'NULL'
		end ScheduledTime
from msdb.dbo.sysjobs j
join msdb.dbo.sysjobsteps js on j.job_id = js.job_id
left join msdb.dbo.sysjobschedules jsch on jsch.job_id = j.job_id
LEFT JOIN msdb.dbo.sysschedules sch on sch.schedule_id = jsch.schedule_id
order by j.name, js.step_id