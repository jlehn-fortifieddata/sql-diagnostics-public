/*============================================================================
  File:     DB Listing - VLFs

  Summary:  Lists the number of VLFs by database.
  
  BOTTOM SCRIPT:  Shrinks the tlog file and adds back.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

	dbcc loginfo('frontdoor')

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


DECLARE @query varchar(1000),
@dbname varchar(1000),
@count int

SET NOCOUNT ON

CREATE TABLE ##loginfo
(
dbname varchar(100),
num_of_rows int)

CREATE TABLE #log_info2012
	(
	recoveryunitid tinyint,
	fileid tinyint,
	file_size bigint,
	start_offset bigint,
	FSeqNo int,
	[status] tinyint,
	parity tinyint,
	create_lsn numeric(25,0)
	)

CREATE TABLE #log_infoOLD
	(
	fileid tinyint,
	file_size bigint,
	start_offset bigint,
	FSeqNo int,
	[status] tinyint,
	parity tinyint,
	create_lsn numeric(25,0)
	)

DECLARE csr CURSOR FAST_FORWARD READ_ONLY
	FOR
	SELECT name
	FROM master.sys.databases
	WHERE state_desc = 'ONLINE'

	OPEN csr

	FETCH NEXT FROM csr INTO @dbname

	WHILE (@@fetch_status <> -1)
	BEGIN

		IF (SELECT CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('PRODUCTVERSION') AS CHAR(2)), 1, 2) IN ('11', '12', '13') THEN 2 ELSE 1 END) = 2
		BEGIN
			SET @query = 'DBCC loginfo (' + '''' + @dbname + ''') '

			INSERT INTO #log_info2012
			EXEC (@query)

			SET @count = @@rowcount

			TRUNCATE TABLE #log_info2012

			INSERT ##loginfo
			VALUES(@dbname, @count)
		END
		ELSE
		BEGIN
			SET @query = 'DBCC loginfo (' + '''' + @dbname + ''') '

			INSERT INTO #log_infoOLD
			EXEC (@query)

			SET @count = @@rowcount

			TRUNCATE TABLE #log_infoOLD

			INSERT ##loginfo
			VALUES(@dbname, @count)
		END

		FETCH NEXT FROM csr INTO @dbname

	END

CLOSE csr
DEALLOCATE csr

SELECT dbname,
	num_of_rows
FROM ##loginfo
WHERE num_of_rows >= 50 --My rule of thumb is 50 VLFs. Your mileage may vary.
ORDER BY dbname

DROP TABLE #log_info2012
DROP TABLE #log_infoOLD
DROP TABLE ##loginfo

/*
DECLARE @file_name sysname,
@file_size int,
@file_growth int,
@shrink_command nvarchar(max),
@alter_command nvarchar(max)

SELECT  @file_name = name,
        @file_size = (size / 128)
FROM    sys.database_files
WHERE   type_desc = 'log'

SELECT @shrink_command = 'DBCC SHRINKFILE (N''' + @file_name + ''' , 0, TRUNCATEONLY)'
PRINT @shrink_command
EXEC sp_executesql @shrink_command

SELECT @shrink_command = 'DBCC SHRINKFILE (N''' + @file_name + ''' , 0)'
PRINT @shrink_command
EXEC sp_executesql @shrink_command

SELECT @alter_command = 'ALTER DATABASE [' + db_name() + '] MODIFY FILE (NAME = N''' + @file_name + ''', SIZE = ' + CAST(@file_size AS nvarchar) + 'MB)'
PRINT @alter_command
EXEC sp_executesql @alter_command
*/