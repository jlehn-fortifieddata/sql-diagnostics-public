/*============================================================================
  File:     DB Details.sql

  Summary:  Lists all the DBs details and bottom code shows the size and free space
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SET NOCOUNT ON


CREATE TABLE #tempdb
(
	dbname sysname,
	dbsize		nvarchar(13) null,
	owner sysname null,
	dbid	smallint,
	created nvarchar(11),
	dbdesc	nvarchar(600)	null,
	cmptlevel	tinyint
)

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (8, 9) 
BEGIN

	INSERT INTO #tempdb
	EXEC sp_helpdb

	SELECT  @@SERVERNAME AS [Server Name]
		, s2.name 'Database Name'
		, s1.name 'File Name'
		, s1.file_id
		, case when type = 1 then 'Log' else 'Data' end 'Type'
		, upper(Physical_Name) 'Physical_Name'
		, s2.state_desc 'State Desc'
		, size/128 'File Size (MB)'
		, max_size 'Max Size'
		, growth 'Growth'
		, dbsize 'Database Size'
		, compatibility_level 'Cmpt Level'
		, collation_name 'Collation'
		, user_access_desc 'User Access'
		, s1.is_read_only 'Read Only'
		, is_auto_close_on 'Auto Close'
		, is_auto_shrink_on 'Auto Shrink'
		, is_auto_create_stats_on
		, is_auto_update_stats_on
		, is_auto_update_stats_async_on
		, is_trustworthy_on
		, is_db_chaining_on
		, is_parameterization_forced
		, is_published
		, is_subscribed
		, recovery_model_desc 'Recovery Model'
		, page_verify_option_desc 'Page Verify'
		, log_reuse_wait_desc 'Log Reuse'
		, dbdesc 'All Options'
		, created
	FROM master.sys.master_files s1
	JOIN master.sys.databases s2 
		ON s1.database_id = s2.database_id
	JOIN #tempdb s3 
		ON dbid = s2.database_id
	ORDER BY 1, 2

	DROP TABLE #tempdb
END

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (1) 
BEGIN

	INSERT INTO #tempdb
	EXEC sp_helpdb

	--select *
	--from #tempdb

	SELECT  @@SERVERNAME AS [Server Name]
		, s2.name 'Database Name'
		, s1.name 'File Name'
		, s1.file_id
		, case when type = 1 then 'Log' else 'Data' end 'Type'
		, upper(Physical_Name) 'Physical_Name'
		, s2.state_desc 'State Desc'
		, size/128 'File Size (MB)'
		, max_size 'Max Size'
		, growth 'Growth'
		, dbsize 'Database Size'
		, compatibility_level 'Cmpt Level'
		, collation_name 'Collation'
		, user_access_desc 'User Access'
		, s1.is_read_only 'Read Only'
		, is_auto_close_on 'Auto Close'
		, is_auto_shrink_on 'Auto Shrink'
		, is_auto_create_stats_on
		, is_auto_update_stats_on
		, is_auto_update_stats_async_on
		, is_trustworthy_on
		, is_db_chaining_on
		, is_parameterization_forced
		, is_published
		, is_subscribed
		, is_cdc_enabled
		, is_encrypted
		, recovery_model_desc 'Recovery Model'
		, page_verify_option_desc 'Page Verify'
		, log_reuse_wait_desc 'Log Reuse'
		, dbdesc 'All Options'
		, created
		--, *
	FROM master.sys.master_files s1
	JOIN master.sys.databases s2 
		ON s1.database_id = s2.database_id
	JOIN #tempdb s3 
		ON dbid = s2.database_id
	ORDER BY 1, 2

	DROP TABLE #tempdb
END



	-- BY DB, SPACE FOR DB AND THE NUMBER OF VLFS
	-- Individual File Sizes and space available for current database
	--SELECT db_name(db_id()) AS 'DB Name'
	--	, name AS [File Name] 
	--	, physical_name AS [Physical Name]
	--	, size/128.0 AS [Total Size in MB]
	--	, size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS int)/128.0 AS [Available Space In MB]
	--	, CASE WHEN [type] = 0 THEN 'Data'
	--		ELSE 'Log' END AS 'Type of File'
	--FROM sys.database_files OPTION (RECOMPILE);

	-- Look at how large and how full the files are and where they are located
	-- Make sure the transaction log is not full!!

	--DBCC LOGINFO;

	-- 'Duplicate Log Files'
	--SELECT @@SERVERNAME AS [Server Name]
	--	, s2.name 'Database Name'
	--	, s1.name 'File Name'
	--	, COUNT(*)
	--FROM master.sys.master_files s1
	--JOIN master.sys.databases s2 on s1.database_id = s2.database_id
	--JOIN #tempdb s3 on dbid = s2.database_id
	--WHERE type = 1
	--GROUP BY s2.name
	--	, s1.name
	--HAVING COUNT(*) > 2