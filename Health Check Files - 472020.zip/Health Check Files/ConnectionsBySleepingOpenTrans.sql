/*============================================================================
  File:     ConnectionsBySleepingOpenTrans

  Summary:  Displays connections with open transactions.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.FORTIFIEDDB.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SELECT DATEDIFF(ss, last_request_start_time, last_request_end_time) [Delta]
	, last_request_start_time
	, last_request_end_time
	, *
FROM SYS.DM_EXEC_SESSIONS s1
JOIN SYS.dm_tran_locks s2
	ON s1.session_id = s2.request_session_id
WHERE SESSION_ID > 50 
AND open_transaction_count = 1 
AND status = 'SLEEPING'
AND s2.resource_type != 'DATABASE'
ORDER BY 1 DESC, 2