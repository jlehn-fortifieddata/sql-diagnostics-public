/*============================================================================
  File:     Top X by WT(CPU)

  Summary:  Provides the TOP X statements based upon total worker time.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Get Top X executed SP's ordered by total worker time (CPU pressure)
SELECT TOP 100 
	@@SERVERNAME 'Server Name'
	, COALESCE(DB_NAME(qt.dbid),'Unknown') AS [DB Name]
	, REPLACE(REPLACE(CAST(SUBSTRING(qt.text, (qs.statement_start_offset/2)+1
                , ((case qs.statement_end_offset
                      when -1 then datalength(qt.text)
                      else qs.statement_end_offset
                   end - qs.statement_start_offset)/2) + 1) AS VARCHAR(1000)), CHAR(10), ''), CHAR(13), '') AS Statement
	, qs.execution_count AS 'Execution Count'
	, qs.execution_count/DATEDIFF(Second, qs.creation_time, GetDate()) AS 'Calls/Second'
	, qs.total_worker_time/qs.execution_count AS 'AvgWorkerTime'
	, qs.total_worker_time AS 'TotalWorkerTime'
	, qs.total_elapsed_time/qs.execution_count AS 'AvgElapsedTime'
	, qs.max_logical_reads
	, qs.last_logical_reads
	, qs.max_logical_writes
	, qs.total_physical_reads
	, DATEDIFF(Minute, qs.creation_time, GetDate()) AS 'Age in Cache'
	, qt.dbid 'DBID'
	, REPLACE(REPLACE(CAST(qt.text as varchar(1000)), CHAR(10), ''), CHAR(13), '') AS 'SPText'
	, GETDATE() AS 'RunTime'
	, (SELECT          
		SUBSTRING(text, (statement_start_offset/2)+1
            , ((case statement_end_offset
                  when -1 then datalength(text)
                  else statement_end_offset
               end - statement_start_offset)/2) + 1)
    FROM sys.dm_exec_sql_text(qs.sql_handle)
    FOR XML PATH(''), TYPE
    ) AS statement_text
	, (SELECT text
		FROM sys.dm_exec_sql_text(qs.sql_handle) AS qt
		FOR XML PATH(''), TYPE) 'SPTextFMT'
	--, query_plan
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY SYS.dm_exec_query_plan(qs.plan_handle) AS qp
WHERE qt.dbid != 32767
--AND qt.dbid = db_id() -- Filter by current database
ORDER BY qs.total_worker_time DESC

/*
-- Top Cached SPs By Total Worker time (SQL Server 2012). Worker time relates to CPU cost  (Query 43)
SELECT TOP(25) p.name AS [SP Name], qs.total_worker_time AS [TotalWorkerTime], 
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.execution_count, 
ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count 
AS [avg_elapsed_time], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID()
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE);

*/