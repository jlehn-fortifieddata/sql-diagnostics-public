/*============================================================================
  File:     Top Cost

  Summary:  Shows the high cost queries.
  
  Date:     2018

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


set transaction isolation level read uncommitted
set nocount on
if object_id('tempdb..#TopQueries') is not null
	drop table #TopQueries

declare @Top int = 20
;with Ranked as
		(select [sql_handle], plan_handle, statement_start_offset, statement_end_offset,
						execution_count, total_logical_reads, total_worker_time, total_elapsed_time, creation_time,
						ROW_NUMBER() over (order by total_worker_time desc) RankByCPU, ROW_NUMBER() over (order by total_logical_reads desc) RankByReads,
						ROW_NUMBER() over (order by total_elapsed_time desc) RankByDuration, ROW_NUMBER() over (order by execution_count desc) RankByExecutionCount,
						cast(total_logical_reads*100./sum(total_logical_reads) over() as decimal(10, 2)) PercentOfReads,
						cast(total_worker_time*100./sum(total_worker_time) over() as decimal(10, 2)) PercentOfCPU,
						min_logical_reads, max_logical_reads, min_worker_time, max_worker_time, min_rows, max_rows, last_execution_time
			from sys.dm_exec_query_stats)
	, AllQueries as
		(select *
			from Ranked
			where RankByCPU <= @Top
				or RankByReads <= @Top
				or RankByDuration <= @Top
				or RankByExecutionCount <= @Top)
select sum(PercentOfReads) PercentOfReads, sum(PercentOfCPU) PercentOfCPU, at.DatabaseName,
		object_name(isnull(ps.object_id, ts.object_id), isnull(ps.database_id, ts.database_id)) ObjectName,
		substring(text, (statement_start_offset/2)+1,
		((case statement_end_offset
				when -1 then datalength(text)
				when 0 then datalength(text)
				else statement_end_offset
			end - statement_start_offset)/2) + 1) SQLStatement,
		min(creation_time) creation_time,
		sum(a.total_logical_reads) total_logical_reads,
		sum(a.total_worker_time) total_worker_time,
		sum(a.execution_count) execution_count,
		sum(a.total_elapsed_time) total_elapsed_time,
		sum(RankByCPU) RankByCPU, max(RankByReads) RankByReads, max(RankByDuration) RankByDuration, max(RankByExecutionCount) RankByExecutionCount, query_plan,
		cast(null as nvarchar(max)) ImplicitlyConvertedColumns, cast(null as nvarchar(max)) ScannedObjects, cast(null as int) LookupCount,
		cast(null as nvarchar(max)) ScalarFunctionsUsed, cast(null as nvarchar(max)) RecommendedIndexes,
		min(a.min_logical_reads) min_logical_reads, max(a.max_logical_reads) max_logical_reads, min(a.min_worker_time) min_worker_time,
		max(a.max_worker_time) max_worker_time, min(a.min_rows) min_rows, max(a.max_rows) max_rows, max(a.last_execution_time) last_execution_time
into #TopQueries
from AllQueries a
	cross apply (select db_name(cast(value as int)) DatabaseName
					from sys.dm_exec_plan_attributes(a.plan_handle) at
					where at.attribute = 'dbid'
						and exists (select *
										from sys.databases d
										where d.database_id = cast(at.value as int)
											and d.state_desc = 'ONLINE')
					) at
	cross apply sys.dm_exec_sql_text(sql_handle) t
	left join sys.dm_exec_procedure_stats ps on a.plan_handle = ps.plan_handle
	left join sys.dm_exec_trigger_stats ts on a.plan_handle = ts.plan_handle
	cross apply sys.dm_exec_text_query_plan(a.plan_handle, statement_start_offset, statement_end_offset) p
group by at.DatabaseName, object_name(isnull(ps.object_id, ts.object_id), isnull(ps.database_id, ts.database_id)),
					substring(text, (statement_start_offset/2)+1,
					((case statement_end_offset
							when -1 then datalength(text)
							when 0 then datalength(text)
							else statement_end_offset
						end - statement_start_offset)/2) + 1), query_plan
go
--begin try
	with xmlnamespaces(default 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')
	update #TopQueries
	set ImplicitlyConvertedColumns = ic.ImplicitlyConvertedColumns,
		ScannedObjects = ic.ScannedObjects,
		LookupCount = ic.LookupCount,
		ScalarFunctionsUsed = ic.ScalarFunctionsUsed,
		RecommendedIndexes = ic.RecommendedIndexes
	from #TopQueries
		outer apply (select 
						stuff((select ',' + isnull(CR.value('@Database', 'nvarchar(128)'), '')
							+ '.' + isnull(CR.value('@Schema', 'nvarchar(128)'), '')
							+ '.' + isnull(CR.value('@Table', 'nvarchar(128)'), '')
							+ '.' + isnull(CR.value('@Column', 'nvarchar(128)'), '')
								from (select Con.query('.') Con
										from x.nodes('//ScalarOperator/Convert[@Implicit="true"]') n(Con)
										) c
									cross apply Con.nodes('//ColumnReference[@Column!=""]') n(CR)
									for xml path('')), 1, 1, '') ImplicitlyConvertedColumns,
						stuff((select ', ' + b.value('@Database', 'nvarchar(128)') + '.' + b.value('@Schema', 'nvarchar(128)') + '.'
									+ b.value('@Table', 'nvarchar(128)') + ' (' + b.value('@Index', 'nvarchar(128)') + ')'
								from x.nodes('//RelOp[@PhysicalOp="Clustered Index Scan" or @PhysicalOp="Index Scan"]//Object') a(b)
								for xml path('')), 1, 2, '') ScannedObjects,
						(select count(*)
							from x.nodes('//IndexScan[@Lookup="true"]') n(lk)) LookupCount,
						stuff((select ',' + sf.value('@FunctionName', 'nvarchar(128)')
							from x.nodes('//ScalarOperator/UserDefinedFunction') n(sf)
							for xml path('')), 1, 1, '') ScalarFunctionsUsed,
						stuff((select ';' + CAST(Index_Impact as nvarchar(100)) + '||'
												+ 'CREATE NONCLUSTERED INDEX [IX_'
												+ replace(replace(Index_Table, '[', ''), ']', '')
												+ '_NC_NU_'
												+ replace(replace(replace(Index_Cols, '[', ''), ']', ''), ',', '#')
												+ isnull('##' + replace(replace(replace(Include_Cols, '[', ''), ']', ''), ',', '#'), '') + ']'
												+ ' ON'
												+ ' ' + Index_DB + '.' + Index_Schema + '.' + Index_Table
												+ '(' + Index_Cols + ')'
												+ isnull(' INCLUDE(' + Include_Cols + ')', '')
								from (select mi.value('@Impact', 'decimal(10, 2)') Index_Impact,
											mi.value('MissingIndex[1]/@Database', 'sysname') Index_DB,
											mi.value('MissingIndex[1]/@Schema', 'sysname') Index_Schema,
											mi.value('MissingIndex[1]/@Table', 'sysname') Index_Table,
											stuff((select ',' + Col.value('@Name', 'sysname')
												from mi.nodes('MissingIndex/ColumnGroup') AS T1(ColumnGroup)
														cross apply ColumnGroup.nodes('Column') T2(Col)
												where ColumnGroup.value('@Usage', 'varchar(100)') in ('EQUALITY', 'INEQUALITY')
												for xml path(''))
												, 1, 1, '') Index_Cols,
											stuff((select ',' + Col.value('@Name', 'sysname')
												from mi.nodes('MissingIndex/ColumnGroup') AS T1(ColumnGroup)
														cross apply ColumnGroup.nodes('Column') T2(Col)
												where ColumnGroup.value('@Usage', 'varchar(100)') in ('INCLUDE')
												for xml path(''))
												, 1, 1, '') Include_Cols
										from x.nodes('//MissingIndexGroup') as T(mi)) t
								for xml path('')), 1, 1, '') RecommendedIndexes
					from (select cast(query_plan as xml) x) q
					) ic
--end try
--begin catch
--end catch

select  *,
        cast(query_plan as xml)
from    #TopQueries
order   by rankbyreads

/*
select  PercentOfReads	                ,
        PercentOfCPU	                ,
        DatabaseName	                ,
        ObjectName	                ,
        replace(replace(replace(SQLStatement, char(13), ' '), char(10), ' '), '	', ' ') as SQLStatement	                ,
        creation_time	                ,
        total_logical_reads	        ,
        total_worker_time	        ,
        execution_count	                ,
        total_elapsed_time	        ,
        RankByCPU	                ,
        RankByReads	                ,
        RankByDuration	                ,
        RankByExecutionCount	        ,
        --replace(replace(query_plan, char(13), ' '), char(10), ' ') as query_plan	                ,
        ImplicitlyConvertedColumns	,
        ScannedObjects	                ,
        LookupCount	                ,
        ScalarFunctionsUsed	        ,
        RecommendedIndexes	        ,
        min_logical_reads	        ,
        max_logical_reads	        ,
        min_worker_time	                ,
        max_worker_time	                ,
        min_rows	                ,
        max_rows	                ,
        last_execution_time
from    #TopQueries
order   by rankbyreads
*/