/*============================================================================
  File:     IO By Drive

  Summary:  Provides IO stall data.
  
  Date:     2008

  Versions: 2005 and 2008
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

SET NOCOUNT ON

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (7, 8) 
BEGIN

	SELECT DB_NAME(d.dbid) 'Database Name'
		, fs.*
		, IoStallMS / (NumberReads + NumberWrites) AS AvgIOTimeMS
		, (NumberReads + NumberWrites) AS NumberIOs
		, case when (NumberReads + NumberWrites) > 5000 then IoStallMS / (NumberReads + NumberWrites) else 0 end AS AvgIOTimeMS_ModifiedForWarning
		--, CAST(io_stall_read_ms/(1.0 + num_of_reads) AS NUMERIC(10,1)) AS 'avg_read_stall_ms'
	FROM ::fn_virtualfilestats (default, default) fs
	JOIN master.dbo.sysdatabases d 
		ON d.dbid = fs.DbId
	ORDER BY AvgIOTimeMS

END

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar), 1) IN (9, 1) 
BEGIN
	---- average stalls per read, write and total
	---- adding 1.0 to avoid division by zero errors
	SELECT 
		@@SERVERNAME AS [Server Name]
		, DB_NAME(fs.database_id) 'Database Name'
		, UPPER(SUBSTRING(physical_name, 1, 1)) AS [drive]
		, fs.file_id
		, physical_name
		, io_stall_read_ms
		, num_of_reads
		, num_of_bytes_read
		, CAST(io_stall_read_ms/(1.0+num_of_reads) AS NUMERIC(10,1)) AS 'avg_read_stall_ms'
		, io_stall_write_ms
		, num_of_writes
		, num_of_bytes_written
		, CAST(io_stall_write_ms/(1.0+num_of_writes) AS NUMERIC(10,1)) AS 'avg_write_stall_ms'
		, io_stall_read_ms + io_stall_write_ms as io_stalls
		, num_of_reads + num_of_writes as total_io
		, CAST((io_stall_read_ms+io_stall_write_ms)/(1.0+num_of_reads + num_of_writes) AS NUMERIC(10,1)) AS 'avg_io_stall_ms'
	FROM sys.dm_io_virtual_file_stats(null,null) fs
	JOIN sys.master_files f 
		on fs.database_id = f.database_id and fs.file_id = f.[file_id]
	ORDER BY avg_io_stall_ms desc

END