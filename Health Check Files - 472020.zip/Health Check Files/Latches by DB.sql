/*============================================================================
  File:     Latches by DB

  Summary:  Provides runtime for latches for all DBs.

  Date:     2013

  Versions: 2005, 2008, 2012
------------------------------------------------------------------------------
  Written by Ben DeBow, FORTIFIED DATA
sp_who2 active	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE master
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON;

DECLARE @DBName NVARCHAR(128)
DECLARE @usecmd NVARCHAR(512)
DECLARE @sqlcmd NVARCHAR(MAX)
DECLARE @fullsqlcmd NVARCHAR(MAX)

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;

CREATE TABLE [tempdb].[dbo].[Results](
	[Server Name] [nvarchar](128) NULL,
	[DB Name] [nvarchar](128) NULL,
	[table_name] [nvarchar](257) NULL,
	[index_name] [sysname] NULL,
	[page_io_latch_wait_count] [bigint] NOT NULL,
	[page_io_latch_wait_in_ms] [bigint] NOT NULL,
	[page_io_avg_lock_wait_ms] [decimal](12, 2) NULL
) ON [PRIMARY]

DECLARE FileName_cursor CURSOR
FOR SELECT SD.[name] 
	FROM sys.databases SD 
	WHERE SD.is_read_only = 0 
		AND SD.state = 0
		AND SD.database_id NOT IN (4)

OPEN FileName_cursor

FETCH NEXT FROM FileName_cursor INTO @DBName

WHILE @@FETCH_STATUS = 0

BEGIN

	SET @usecmd = 'USE [' + @DBName + '];'
	SET @sqlcmd = '
		-- LATCH RESULTS FOR EACH OBJECT\INDEX
		INSERT INTO tempdb.dbo.Results
		SELECT TOP 10 @@SERVERNAME AS [Server Name] 
			, DB_NAME() AS [DB Name]
			, OBJECT_SCHEMA_NAME(ios.object_id) + ''.'' + OBJECT_NAME(ios.object_id) as table_name
			, i.name as index_name
			, page_io_latch_wait_count
			, page_io_latch_wait_in_ms
			, CAST(1. * page_io_latch_wait_in_ms / NULLIF(page_io_latch_wait_count ,0) AS decimal(12,2)) AS page_io_avg_lock_wait_ms
		FROM sys.dm_db_index_operational_stats (DB_ID(), NULL, NULL, NULL) ios
		JOIN sys.indexes i 
			ON i.object_id = ios.object_id 
			AND i.index_id = ios.index_id
		WHERE OBJECTPROPERTY(ios.object_id,''IsUserTable'') = 1
		'

	SET @fullsqlcmd = @usecmd + @sqlcmd

	EXEC(@fullsqlcmd)

	FETCH NEXT FROM FileName_cursor INTO @DBName

END

CLOSE FileName_cursor
DEALLOCATE FileName_cursor

SELECT *
FROM tempdb.dbo.Results
GO

IF OBJECT_ID('tempdb.dbo.Results') IS NOT NULL
	DROP TABLE tempdb.dbo.Results;
