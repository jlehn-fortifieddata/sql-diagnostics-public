/*============================================================================
  File:     Top X by exec CNT

  Summary:  Provides the TOP X statements based upond total EXEC time.
  
  Date:     2008

  Versions: 2005, 2008, 2012, 2014, 2016, 2017
------------------------------------------------------------------------------
  Written by Ben DeBow, Fortified Data
	
  For more scripts and sample code, check out 
    http://www.fortifieddata.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- REPLACE(CAST(TextData AS VARCHAR(MAX)), CHAR(13) + CHAR(10), ', ')

-- Get Top X executed SP's ordered by execution count
SELECT TOP 100 
	@@SERVERNAME 'Server Name'
	, COALESCE(DB_NAME(qt.dbid),'Unknown') AS [DB Name]
	, CAST(substring(qt.text, (qs.statement_start_offset/2)+1
                , ((case qs.statement_end_offset
                      when -1 then datalength(qt.text)
                      else qs.statement_end_offset
                   end - qs.statement_start_offset)/2) + 1) AS VARCHAR(500)) as Statement
	, qs.execution_count AS 'Execution Count'
	, qs.execution_count/DATEDIFF(Second, qs.creation_time, GetDate()) AS 'Calls/Second'
	, qs.total_worker_time/qs.execution_count AS 'AvgWorkerTime'
	, qs.total_worker_time AS 'TotalWorkerTime'
	, qs.total_elapsed_time/qs.execution_count AS 'AvgElapsedTime'
	, qs.max_logical_reads
	, qs.last_logical_reads
	, qs.max_logical_writes
	, qs.total_physical_reads
	, total_rows
	, qs.last_rows
	, qs.min_rows
	, qs.max_rows
	, DATEDIFF(Minute, qs.creation_time, GetDate()) AS 'Age in Cache'
	--, (SELECT text
	--	FROM sys.dm_exec_sql_text(qs.sql_handle) AS qt
	--	FOR XML PATH(''), TYPE) 'SPTextFMT'
	, query_plan
	, CAST(qt.text AS VARCHAR(500))  AS 'SPText'
	, GETDATE() AS 'RunTime'
	--, (
 --       SELECT          
	--		substring(text, (statement_start_offset/2)+1
 --               , ((case statement_end_offset
 --                     when -1 then datalength(text)
 --                     else statement_end_offset
 --                  end - statement_start_offset)/2) + 1)
 --       FROM sys.dm_exec_sql_text(qs.sql_handle)
 --       FOR XML PATH(''), TYPE
 --   ) AS statement_text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
--WHERE qt.dbid != 32767
--AND CAST(qt.text IS NOT NULL
--WHERE qt.dbid = db_id() -- Filter by current database
--where qt.dbid != 7
--where substring(qt.text, (qs.statement_start_offset/2)+1
--                , ((case qs.statement_end_offset
--                      when -1 then datalength(qt.text)
--                      else qs.statement_end_offset
--                   end - qs.statement_start_offset)/2) + 1) like '%#history%'
ORDER BY qs.execution_count DESC
--ORDER BY qs.execution_count/DATEDIFF(Second, qs.creation_time, GetDate()) DESC

/*
SELECT TOP 20
LEFT(P.CACHEOBJTYPE + '(' +P.OBJTYPE + ')', 35) AS cacheobjtype,
p.usecounts,
p.size_in_bytes / 1024 AS SIZE_IN_KB,
stat.total_worker_time/1000 AS TOT_CPU_MS,
stat.total_elapsed_time/1000 AS TOT_DURATION_MS,
stat.total_physical_reads,
stat.total_logical_writes,
stat.total_logical_reads,
LEFT (CASE
                WHEN PA.VALUE=32767 THEN 'ResourceDb'
                ELSE ISNULL (DB_NAME (CONVERT (sysname, pa.value)), CONVERT (sysname, pa.value))
                END, 40) AS dbname,
sql.objectid,
CONVERT (NVARCHAR(50), CASE
                WHEN sql.objectid IS NULL THEN NULL
                ELSE REPLACE (REPLACE (sql.[text], CHAR(13), ' '), CHAR(10), '')
                END) as PROCNAME,
                REPLACE(REPLACE(SUBSTRING (sql.[text], stat.statement_start_offset/2 + 1,
CASE WHEN stat.statement_end_offset = -1 THEN LEN (CONVERT (nvarchar(max), sql.[text]))
ELSE stat.statement_end_offset / 2 - stat.statement_start_offset / 2 + 1 END),
                CHAR(13), ' '), CHAR(10), ' ') AS STMT_TEXT,
                QPLAN.Query_Plan
FROM sys.dm_exec_cached_plans p
OUTER APPLY sys.dm_exec_plan_attributes (p.plan_handle) pa
INNER JOIN sys.dm_exec_query_stats stat ON p.plan_handle = stat.plan_handle
OUTER APPLY sys.dm_exec_sql_text (p.plan_handle) AS sql
OUTER APPLY sys.dm_exec_query_plan(p.plan_handle) as QPLAN
WHERE pa.attribute = 'dbid'
ORDER BY tot_cpu_ms DESC
*/